# ASTRA POINT — Supabase live connection

This package is configured for the Supabase project used for the dedicated ASTRA schema. The browser client uses only the project's publishable/anon key; never put a service-role key in a Vite `.env` file.

## Project
- Project ref: `hktpuwhhhasezylkkbzm`
- API URL: `https://hktpuwhhhasezylkkbzm.supabase.co`
- Client key: `VITE_SUPABASE_PUBLISHABLE_KEY` in `.env`

## Database setup already applied
- `astra_user_profiles`: Supabase Auth-linked profiles. New signups default to `student_participant`.
- `astra_app_state`: JSON state for the app's listed operational modules, with row-level security and Realtime enabled.
- Policies: signed-in users can read global state; only elevated profiles can write shared state; each user can write their own user-scoped state.
- `astra_auth_user_created` trigger creates a profile for each new Auth user.

The matching migration is in `supabase/migrations/202610230001_astra_point_live_sync_auth.sql`. The profile policy correction and trigger lockdown were also applied to the live project.

## Run locally
1. Install Node.js 20+.
2. Run `npm install`.
3. Run `npm run dev` and open the URL Vite prints.
4. Use **New student? Create an account**, enter a real email, and verify it if email confirmation is enabled.
5. Sign in on each device using the same Supabase Auth account. The `liveSync.ts` bridge hydrates configured operational keys and subscribes to Realtime updates.

## Important role bootstrap
Public signups are deliberately assigned `student_participant`; a user must not be able to make themselves an administrator. After the intended administrator signs up, promote that exact account through the Supabase SQL editor after verifying its email:

```sql
-- Replace with the exact verified email that signed up.
update public.astra_user_profiles p
set role_key = 'platform_admin', updated_at = now()
from auth.users u
where p.user_id = u.id
  and lower(u.email) = lower('YOUR_VERIFIED_ADMIN_EMAIL');
```

Do not run the query until the email is verified and confirmed as the intended administrator. This is required before shared operational modules can write to the database.

## Data and limitations
- Theme and dashboard widget order remain device-local by design.
- The live sync bridge covers the operational local-storage keys listed in `src/liveSync.ts`. Existing feature components that still show “local/browser demo” wording or don't use those keys directly still need feature-specific integration before they should be treated as production-ready.
- Public portal content is still read from local browser storage and static bundled defaults; public unauthenticated cross-device publishing is not enabled by this first migration.
- Student application review and some legacy demo modules require a follow-up data-model pass to make submissions, staff review, and cross-account views share one canonical record safely.
- The ZIP's build could not be verified in this environment because npm dependencies could not be downloaded. Run `npm install && npm run build` before deploying.


## Dedicated ASTRA schema note
The new `astra` schema is separate from `public`. Add `astra` under Project Settings → API → Exposed schemas before using `.schema('astra')` from the browser. The current app build reads authenticated profiles from `astra.profiles`; feature screens for events, approvals and announcements still require their next integration pass and should not be treated as cloud-synced yet. See `ASTRA_SCHEMA_INTEGRATION.md`.
