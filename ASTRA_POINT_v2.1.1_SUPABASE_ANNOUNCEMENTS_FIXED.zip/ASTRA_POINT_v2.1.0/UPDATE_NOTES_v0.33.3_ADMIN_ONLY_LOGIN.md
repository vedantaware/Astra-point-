# ASTRA POINT v0.33.3 — Super Admin-only login

- Preserved the existing public home page and its original visual design, colours, typography and stylesheets.
- Removed public student registration and account creation from the login flow.
- Restricted local and Supabase-authenticated workspace sessions to active `platform_admin` profiles.
- Changed login copy to identify the single Super Admin entry point.
- Removed the in-app account provisioning UI so the portal does not create council/member accounts.
- Public visitors continue to browse the existing public portal without signing in.

Security note: the frontend role check is not a replacement for Supabase RLS. Keep publishing permissions restricted to the Super Admin in database policies as well.
