# ASTRA POINT v0.29.0 — Dedicated ASTRA Supabase schema

- Updated the sample Supabase URL to project `hktpuwhhhasezylkkbzm`.
- Updated authenticated profile hydration to read `astra.profiles` and map its role/status to the app's existing profile model.
- Added setup instructions for exposing the `astra` schema through Supabase's API settings and configuring the publishable key in `.env.local`.
- Documented the five isolated ASTRA tables and RLS/security boundaries.
- Explicitly documented that Events, Approvals, Announcements, and other operational screens remain local-state prototypes until feature-specific database adapters are implemented.
- The schema and profile-trigger migrations were applied to the connected Supabase project and table existence/RLS were verified.
- Build validation was not completed because `npm install` timed out in this environment.
