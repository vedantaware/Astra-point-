# ASTRA POINT v0.32.0 — Supabase integration status

Project ref: `hktpuwhhhasezylkkbzm`
API URL: `https://hktpuwhhhasezylkkbzm.supabase.co`
Schema: `astra`

## Dedicated ASTRA tables provisioned

- `profiles`, `events`, `approvals`, `announcements`, `approval_history`
- `teams`, `team_members`, `tasks`, `budgets`, `expenses`, `meetings`, `attendance`
- `feedback_forms`, `feedback_responses`, `notifications`, `audit_logs`, `app_state`

RLS is enabled on these tables. Role- and owner-scoped policies are installed. The `astra` schema is configured for the PostgREST API; the schema must remain exposed in Supabase API settings for `.schema('astra')` client calls to work.

## UI integration in this package

**Direct relational-table integration:**
- Events: reads and creates event rows in `astra.events`.
- Approvals: submits requests, records decisions and attempts to append approval history in `astra.approvals` / `astra.approval_history`.
- Announcements: reads, creates, publishes and deletes rows in `astra.announcements`.
- Authentication profile hydration: reads `astra.profiles`; new Auth users get a default `student_participant` profile.

**Per-account cloud-state synchronization:**
A reusable hook syncs these existing UI state modules to `astra.app_state` keyed by authenticated user ID and state key: tasks, budget UI registers, meetings, student application UI, committees, media metadata, certificate UI registers, feedback form metadata, inventory, partnerships, election nomination placeholders, team roster UI, website CMS content, achievement records, submission placeholders, profile preferences, letter request drafts, and governance-demo toggles. This gives the same signed-in user persistence across devices, but it is not yet a shared relational workflow between different users. Legacy UI models are stored as JSON payloads and are not automatically migrated into the dedicated normalized tables listed above.

## Not yet production-complete

- `tasks`, `budgets`, `expenses`, `meetings`, `attendance`, `feedback_forms`, `feedback_responses`, `notifications`, `teams`, `team_members`, `inventory`, partnerships, and elections still need dedicated table CRUD and multi-user workflow wiring where applicable. Some currently persist as per-user JSON state only.
- Email delivery, anonymous public portal data access, actual feedback answer submission, secure voting, file uploads, verified attendance, and a server-generated append-only audit trail are not implemented.
- Cloud-state data is private to each authenticated user; it is not automatically shared with teammates or admins.
- Do not put a service-role key in frontend code. `.env.local` contains only the project's publishable key.

## Run

```bash
npm install
npm run dev
```

A production build could not be verified in the build environment because dependency installation timed out. Run `npm run build` locally and test each role before deploying.


## v0.32 cloud state and task integration

- Operational workspace keys are synchronized through `astra.app_state` with a shared global scope; user submissions/profile preferences remain account-scoped.
- Realtime subscriptions listen for changes to the same state key in the `astra` schema.
- Tasks now use `astra.tasks` for list, create and completion updates; `assignee_name` is a display label and does not itself grant account access. Database RLS remains the access boundary.
- Events, approvals and announcements continue using their dedicated relational tables.
- Budget, teams/rosters, meetings, inventory, certificates, media, CMS and some other screens still use shared JSON state for the current UI. They are not yet fully relational CRUD workflows; they should be migrated screen-by-screen before production.
- The `src/liveSync.ts` legacy hook that referenced `public.astra_app_state` was removed because it was unused and conflicted with the dedicated schema.

### Apply the migration

For a fresh project, create the ASTRA core schema first, then apply `supabase/migrations/202610280001_shared_astra_state_and_tasks.sql`. The connected Supabase project has already received the equivalent change. Do not blindly rerun older historical migrations that create similarly named tables in `public`.

## v0.33.0 relational workflow update
Budget, expenses, teams/rosters, meetings/minutes, meeting self-attendance, feedback forms/responses, notifications, and audit history now use direct relational queries instead of shared JSON state for those screens. The migrations add optimistic version counters, idempotent feedback submissions, server-side audit triggers, open-form submission enforcement, self-attendance RLS, and append-only audit access. Run `npm run test:permissions` for static RLS regression checks. Live multi-role testing and the production build remain blocked until test Auth users are provisioned and npm dependencies can be installed.
