# ASTRA POINT v0.33.2 — TypeScript build fixes

## Fixes
- Narrow the nullable Supabase client into a local constant before asynchronous cloud-state operations.
- Use an explicit `LucideIcon` navigation item type while flattening navigation groups for the mobile More menu, avoiding `unknown` item inference and incompatible readonly tuple unions.

## Verification
- Source-level checks and ZIP integrity are performed for this package.
- A production build could not be run in the packaging environment because `npm install --no-audit --no-fund` timed out before dependencies were installed. Run `npm install` and `npm run build` locally to verify with the project's dependency versions.
