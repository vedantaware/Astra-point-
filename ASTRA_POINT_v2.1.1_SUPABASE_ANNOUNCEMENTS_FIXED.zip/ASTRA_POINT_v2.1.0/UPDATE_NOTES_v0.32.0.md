# ASTRA POINT v0.32.0 — Shared cloud workflows

## Implemented
- Fixed the active cloud-state hook to use the dedicated `astra.app_state` table instead of the obsolete `public.astra_app_state` table.
- Added scoped shared state rows (`global:<key>`) for shared operational UI state and user-owned rows (`<user-id>:<key>`) for personal submissions/preferences.
- Added Supabase Realtime subscription per state key so other signed-in sessions receive shared state changes.
- Added hydration gating to avoid writing local fallback state before the initial cloud read completes. Existing browser-only operational data is not automatically copied into the shared cloud state.
- Connected task listing, creation and completion updates to the relational `astra.tasks` table.
- Events, approvals and announcements continue to use dedicated relational tables.
- Added the idempotent migration file `supabase/migrations/202610280001_shared_astra_state_and_tasks.sql`.

## Still not fully relational
Budget requests/allocations/expenses, team rosters, committees, meetings, attendance, media, certificates, CMS, inventory, feedback submission UI, notifications and some other screens still use the shared JSON workspace state. Database tables exist for several of these, but their forms have not all been migrated to direct CRUD. Do not treat this build as production-ready until those screens are migrated and permission-tested.

## Important setup notes
- Use the Supabase project URL and publishable key in `.env.local`; never use a service-role key in frontend code.
- The project must expose the `astra` schema through Supabase API settings and have `astra.app_state` in the Realtime publication. The connected project has already received the matching database changes.
- The local production build was not verified in this environment because dependency installation timed out. Run `npm install` and `npm run build` locally and fix any reported errors before deployment.
