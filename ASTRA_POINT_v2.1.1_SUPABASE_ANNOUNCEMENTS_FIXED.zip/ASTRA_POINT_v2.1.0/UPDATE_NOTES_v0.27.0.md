# ASTRA POINT v0.27.0 — Public Home Experience

## What changed
- Reworked the public portal into a compact, app-like landing experience rather than one long page.
- Added a campus pulse overview with latest public announcements and upcoming events.
- Added direct exploration shortcuts for council, clubs, teams, Hall of Fame, services and the student workspace.
- Restyled the hero around the existing real council photograph and the current warm ivory / burgundy visual direction.
- Navigation now presents the selected public section as a focused page view; Home returns to the overview.
- Preserved existing public data sources, CMS state, navigation labels, login callback and content sections.
- Added responsive layout adjustments and reduced-motion support.

## Validation
- Source and asset paths inspected.
- ZIP archive integrity checked after packaging.
- A production build was not verified because dependency installation timed out in this environment.
