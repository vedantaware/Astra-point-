import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const app = readFileSync(new URL('../src/App.tsx', import.meta.url), 'utf8');
const data = readFileSync(new URL('../src/astraData.ts', import.meta.url), 'utf8');
const migrations = ['202610280001_shared_astra_state_and_tasks.sql','202610280002_astra_relational_workflows_audit_and_versions.sql','202610280003_astra_roster_profile_read_and_append_only_audit.sql','202610280004_astra_audit_core_operations.sql','202610280005_astra_self_attendance_and_rls.sql','202610280006_astra_feedback_open_form_guard_and_recipient_lookup.sql','202610280007_astra_feedback_and_roster_policy.sql','202610280008_astra_attendance_self_service.sql','202610280009_astra_audit_trigger_only_insert.sql','202610280010_astra_feedback_form_questions.sql','202610280011_astra_index_cleanup.sql','202610280012_astra_fix_audit_changed_fields_trigger.sql','202610280013_astra_feedback_identity_mode_guard.sql'];
const read = (name) => readFileSync(new URL(`../supabase/migrations/${name}`, import.meta.url), 'utf8');

const roleKeys = ['platform_admin','institution_approver','faculty_coordinator','council_president','event_organizer','treasurer','committee_member','club_lead','student_participant','auditor_readonly'];
for (const role of roleKeys) assert.match(app, new RegExp(`['\"]${role}['\"]`), `Missing UI role mapping: ${role}`);
for (const name of ['fetchBudgets','createBudget','createExpense','reviewExpense','fetchTeams','createTeam','updateTeam','deleteTeam','fetchMeetings','createMeeting','updateMeeting','fetchFeedbackForms','createFeedbackForm','submitFeedbackResponse','fetchNotifications','markNotificationRead','fetchAuditLogs','markMyMeetingAttendance','createNotification','fetchProfiles']) assert.ok(data.includes(`function ${name}(`), `Missing relational data function: ${name}`);
const sql = migrations.map(read).join('\n');
for (const table of ['teams','budgets','expenses','meetings','feedback_forms','feedback_responses','notifications','events','approvals','announcements','tasks','attendance']) assert.ok(sql.includes(`on astra.${table}`), `Missing audit/relational migration coverage: ${table}`);
assert.match(sql, /audit_logs_no_client_update[\s\S]*using \(false\) with check \(false\)/i, 'Audit updates must be denied to authenticated clients');
assert.match(sql, /audit_logs_no_client_delete[\s\S]*using \(false\)/i, 'Audit deletes must be denied to authenticated clients');
assert.match(sql, /feedback_responses_submit[\s\S]*status = 'Open'/i, 'Feedback submissions must require an open form');
assert.match(data, /eq\('version',expectedVersion\)/, 'Version-checked updates must reject stale writes');
assert.match(sql, /attendance_submit_self[\s\S]*user_id = \(select auth\.uid\(\)\)/i, 'Self-attendance insert must be scoped to the caller');
console.log(`Role-policy static checks passed: ${roleKeys.length} UI roles; relational CRUD helpers and RLS migration invariants verified.`);
console.log('Note: live RLS impersonation and browser E2E require seeded Supabase Auth users and installed frontend dependencies.');
