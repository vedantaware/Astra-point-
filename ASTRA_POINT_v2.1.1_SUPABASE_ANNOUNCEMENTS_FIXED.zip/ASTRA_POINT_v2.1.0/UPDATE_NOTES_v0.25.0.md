# ASTRA POINT v0.25.0 — Supabase live-sync foundation

- Connected client configuration to the new ASTRA POINT Supabase project in Mumbai.
- Added Supabase Auth email sign-in and student self-registration (new accounts default to `student_participant`).
- Added `astra_user_profiles` and `astra_app_state` with row-level security.
- Added a local-storage compatibility bridge that hydrates configured operational keys from Supabase and subscribes to Realtime updates across signed-in devices.
- Added the live migration file and setup/bootstrap instructions in `LIVE_SUPABASE_SETUP.md`.
- Existing UI modules are preserved. This is a live-sync foundation, not yet a claim that every legacy demo module has been converted to production-grade relational CRUD. See limitations in `LIVE_SUPABASE_SETUP.md`.
- Build validation is pending because npm package downloads were unavailable in this environment.
