# ASTRA POINT v0.20.0 — Campus events

Added the council-provided campus event history to the public student portal and the existing event workspace.

## Completed
- SIH INTERNAL HACKATHON 2026 — 27 August 2026
- Teachers Day — 7 September 2026
- Avishkar 2026 — 15 September 2026
- Induction program of first year — 16 September 2026
- Garba Raas — 19 September 2026
- Engineer's Day — 22 September 2026

## Upcoming
- Spandan 2K27 — January–February 2027 (exact date and schedule not yet provided)

Event seed records are in `src/data/events.ts`. The portal displays completed records as historical events and counts only upcoming published events in its upcoming-event statistic. The app seeds the local event workspace only when it is empty; non-empty existing local event records are preserved. No Supabase remote data, schema, or authentication settings are changed.
