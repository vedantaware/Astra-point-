# Permission test plan (manual, use a dedicated development project)
# Never run destructive tests against the shared/production project.
- [ ] anonymous select on astra_access_profiles is denied
- [ ] authenticated user reads only their own profile
- [ ] non-admin call to astra-admin-users returns HTTP 403
- [ ] platform_admin can create a normal role account
- [ ] platform_admin cannot create another platform_admin through regular endpoint
- [ ] duplicate username is rejected and orphan Auth user is cleaned up
- [ ] inactive account cannot enter the workspace
- [ ] committee/student cannot publish events
- [ ] browser client cannot write event approvals or audit logs
- [ ] participant cannot read another participant's registration
- [ ] existing tables/policies/data remain unchanged
