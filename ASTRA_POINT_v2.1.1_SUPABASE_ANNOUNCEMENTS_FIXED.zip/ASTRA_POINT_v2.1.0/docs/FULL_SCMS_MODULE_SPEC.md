# ASTRA POINT — Full Student Council Management System Specification

Version: 0.9.0 prototype specification  
Status: frontend-first; database design intentionally deferred

## Product definition
ASTRA POINT is a Student Council Management System (SCMS). The public Student Council Portal is its pre-login landing page. The authenticated workspace is the private operating environment for council members, leads, coordinators, approvers and administrators. This product is not an academic ERP; academic marks, fees, payroll, examinations and timetables are out of scope unless separately approved.

## Design commitments
- Public portal: use the supplied Siddhant College Student Council crest and supplied ASTRA mark; keep the hero team-photo area blank until the real photo is supplied.
- Minimal, responsive design with light/dark theme, split-screen login, role-specific workspace and English UI.
- Public portal only displays content explicitly marked for public publication.
- Never invent council identities, passwords, IDs, verified status or institutional statistics. Flag uncertain source transcriptions.
- All current prototype data is illustrative/local and not authoritative.

## Module inventory and intended connected workflows

### 1. Identity, roles and access
Admin-provisioned unique username/password accounts; account activation/suspension; role assignment; password reset/change; session handling; profile self-view; least-privilege module and record access; trusted server-side permission enforcement; security audit events. Role-aware navigation is not security enforcement.

### 2. Council directory and terms
Verified member records, positions, student/faculty type, committee membership, council term, active/inactive state, member profile and public visibility approval. Workflow: create/import draft → verify source → authorize → publish permitted fields → term rollover/archive. No unverified source record should silently become verified.

### 3. Committees and teams
Create committee, appoint lead/coordinator, assign members, set term and scope, manage team announcements/tasks/documents, track work, hand over at term end. Membership and announcement audiences must resolve from verified active memberships.

### 4. Announcements and communication
Composer: title, body, attachment metadata, audience, priority, publish time, expiry, acknowledgement requirement and public-portal toggle. Audiences: own team/committee; authorized council leads; all active council members; selected recipients if permitted; public Student Council Portal. Public publishing requires explicit authorization and must be distinct from internal council-wide distribution. Lifecycle: draft → preview → optional approval → scheduled/published → delivery/read/acknowledgement tracking → archive/withdraw. Record edits and withdrawals in the audit trail. Email and in-app delivery are future integrations; never show delivery success without provider confirmation.

### 5. Event lifecycle
Draft proposal → submit → faculty/coordinator review → return for revision or recommendation → authorized final approval → approved → explicitly publish → registration open → registration close/waitlist → attendance/check-in → post-event report → close/archive. Rejections require a reason. Keep submitter and approver separation where policy requires. Display the configured review SLA (currently proposed as 48 hours) and escalate through a backend scheduler later; a browser timer is not authoritative.

### 6. Registrations and attendance
Event eligibility, capacity, duplicate-registration prevention, waitlist promotion, cancellation, QR check-in and attendance corrections. Protect student personal data and expose only necessary attendee fields to event staff. QR tokens must be unguessable and validated server-side in production.

### 7. Tasks, projects and volunteers
Tasks/subtasks, owner, committee, priority, due date, dependencies, evidence, comments, status and escalation. Tasks can be linked to events, meetings and decisions. Completion rate must derive from persisted tasks rather than fabricated statistics.

### 8. Meetings and decisions
Schedule meeting, invite eligible participants, prepare agenda, record attendance, save minutes, create assigned action items, track decision owner/deadline and preserve revisions. Calendar invitations are sent only after a real integration reports success.

### 9. Approvals
Configurable workflows, role-authorized decisions, comments/reasons, conflict/self-approval prevention, return/revise/reject/approve states, SLA and full decision history. Never trust client-supplied role claims; authorize every transition on the server.

### 10. Finance and budgets
Event/committee budget request, itemized lines, attachments/receipts, approval chain, committed amount, recorded expenses, budget variance and export. Separate requestor, approver and finance duties according to policy. Approval UI is not proof of payment; actual payments are out of scope unless separately designed.

### 11. Inventory and resources
Asset register, category, asset tag, location, custodian, condition, availability, issue/return, maintenance and disposal approvals. Resource booking can link equipment/venue to events. Changes require actor/time audit records. Current module is only a local prototype register.

### 12. Partnerships and sponsors
Prospect → contacted → discussion → proposed contribution → commitment verified → deliverables tracked → completed/closed. Track contact owner, agreement evidence, deliverables, conflicts and follow-up dates. Never present a prospect or proposed contribution as a confirmed sponsor.

### 13. Documents and media
Metadata, authorized uploads, private/public classification, review/approval, version history, retention, access-controlled downloads and public media approval. Future storage must use restricted buckets/signed URLs where appropriate; filenames alone are not uploaded files.

### 14. Certificates and achievements
Eligibility rules, draft batches, verified attendance/achievement, authorized issue, unique certificate reference, verification page and revocation. Actual PDF generation/signing and public verification are not yet implemented.

### 15. Feedback and grievances
Configurable forms, submission window, privacy notice, optional anonymity only where feasible, triage, assignment, resolution, retention and aggregated reporting. Avoid exposing identity to unauthorized reviewers. Do not promise anonymity if logs or workflow can identify the submitter.

### 16. Elections
Election setup, rules, positions, nomination window, candidate consent, eligibility verification, reviewer separation, voting window, duplicate-vote prevention, secret ballot, independent tally, result approval and publication. Current UI is only nomination placeholders; do not use it for a real election until threat modeling and a secure backend are implemented and tested.

### 17. Notifications
In-app inbox, email preference and delivery states, reminders, scheduled delivery, retry/error state, acknowledgement and unsubscribe/preferences where appropriate. Do not send to unauthorized audiences. Keep provider secrets server-side.

### 18. Reports and analytics
Role-filtered event, attendance, task, finance, engagement, inventory and committee reports; CSV/PDF export; report timestamp and scope; data provenance; privacy controls. Exports must be based on verified persisted records and be permission-checked server-side.

### 19. Audit and governance
Server-generated actor, action, entity, timestamp, result and safe metadata; append-only where feasible; protected access; export policy; retention; no secrets or passwords in logs. Current screen shows illustrative examples only and is not an audit ledger.

### 20. Settings and system administration
Institution/council term, workflow configuration, categories, templates, notification preferences, account management, data retention and system status. High-impact configuration changes require confirmation and audit history.

## Role model (proposed; institution must confirm)
- Platform administrator: system configuration and account lifecycle; not automatically authorized to make institutional decisions.
- Institutional approver: designated institutional-level decisions.
- Faculty coordinator: assigned council/committee oversight and event review.
- Council president: council-wide operational leadership.
- Event organizer: assigned event planning and execution.
- Treasurer: finance workflows.
- Committee lead: assigned committee operations.
- Committee member: assigned team tasks and content.
- Student participant: public content, permitted event registration, own records and feedback.
- Auditor/read-only: approved records and reports without mutation.

Role names alone are insufficient. Each operation must evaluate action + resource + scope + active membership + workflow state on the server.

## Database-later rule
Do not create or alter database tables during the UI phase. First validate screens, state transitions, permissions matrix, empty/error/loading states and end-to-end acceptance scenarios using mock data. Then map the approved workflows into an additive schema, inspect the target project's current tables/policies/functions, test migration and RLS in a separate safe environment, and obtain explicit approval before applying anything to a live project. Do not reset, truncate or delete existing data.

## Minimum acceptance criteria before database design
1. Each screen is navigable at mobile and desktop breakpoints.
2. Every form has required-field validation, cancellation and success/error state.
3. Workflow transitions have explicit allowed source/target states and required reasons.
4. Audience selection previews the target and makes public vs internal scope obvious.
5. Demo records and statistics are visibly labelled as illustrative.
6. No mock action claims that email, upload, payment, authentication, certificate or election actually occurred.
7. Every role has a documented access matrix; prohibited actions are tested.
8. Council source ambiguities remain flagged for human verification.
9. Accessibility includes keyboard navigation, focus states, labels, contrast and reduced-motion support.
10. Production build and browser/device tests pass before the prototype is called complete.
