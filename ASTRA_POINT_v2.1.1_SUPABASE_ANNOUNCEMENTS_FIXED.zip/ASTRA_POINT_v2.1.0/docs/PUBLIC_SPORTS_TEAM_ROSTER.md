# ASTRA POINT – Public sports team roster

The Home Page Teams section now loads published rosters from `public.campus_sports_team_members`.
The table is readable by `anon` and `authenticated` only for rows where `is_published = true`.
Writes remain restricted to authenticated users and must also satisfy the project's RLS policies.

The Kabaddi Team roster is seeded in the live ASTRA POINT Supabase project:
- Pragati Sarnaik — SE AIML
- Aishwarya Shevkari — SE AIML
- Aashlesha Nawale — SE ECE
- Dnyeshwari Madke — SE AIML
- Sakshi Patil — SE AIML
- Pranali Ghogare — SE AIML
- Sanjivani Chevale — SE AIDS
- Rutuja Ubale — SE AIDS
- Vaishnavi Hagwane — SE Mechanical

Set `is_published = false` to hide a member from the public page. Changes are reflected through Supabase Realtime when the table is included in the `supabase_realtime` publication.
