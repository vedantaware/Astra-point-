# ASTRA POINT v0.14.0 — verification status

## Source checks performed (13 Oct 2026)
- TypeScript `transpileModule` syntax transpilation on `src/App.tsx`, `src/PublicPortal.tsx`, `src/AuthRoot.tsx`, `src/AuthVisual.tsx`, and `src/main.tsx`: passed with no syntax diagnostics.
- ZIP integrity: verified after packaging (see delivery report).
- Production build (`npm run build`): **not passed / not verified**. The environment does not have the React, lucide-react, Recharts, and Supabase JS dependencies installed. `npm install --no-audit --no-fund` timed out and offline installation failed because the package cache lacks the Supabase JS package. Running `npm run build` consequently fails with missing-module/type errors; these are not evidence of a successful production build.
- Automated unit/browser tests: not present in package scripts and not run.

## Demo certificate workflow
- Local browser persistence uses namespaced `astra-demo-cert-batches-v1` and `astra-demo-cert-records-v1` localStorage keys. It does not call Supabase or modify existing database records.
- Batch setup includes event, certificate type, college/club-specific branding, approval policy, approval requirement, selected demo recipients and portal-plus-email delivery intent.
- Approval-required batches must be approved in the demo before issue. Approval is a simulated UI state only.
- Issuance adds one local record per selected demo recipient and avoids creating duplicate records for the same recipient within a batch.
- Issued records appear in the certificate register; preview/print opens a printable demo certificate, and register CSV export is available.
- Email delivery is **simulated**; no email provider is configured and no messages are sent. Student portal cards are not linked to a real student identity/backend in this prototype.
- Club Lead demo role is available in the role switcher and is scoped to the sample Innovation Club. This is client-side demo filtering, not a security boundary; enforce scope server-side before production.

## Production blockers
Install dependencies successfully, run a full `npm run build`, add automated tests for approval transitions/duplicate issuance/role scoping, implement backend-enforced authorization and actual email delivery, and validate generated certificate details and signatory approvals with the college before production use.


## v0.15.0 bug-fix verification

Login now accepts username or email; certificate print values are HTML-escaped; CSV export protects formula-leading cells and handles blob URL cleanup; local demo approval decisions have a local history record. Dependency installation timed out, so build/lint/browser regression remain unverified. See `BUGFIX_REPORT_v0.15.0.md`. No live backend changes were made.
