# SCMS v4 feature and data integration

## Imported from SCMS_v4_bundle.zip

- Official Student Council 2026–27 selection report PDF, dated 21 August 2026, copied to `public/documents/Student_Council_2026-27_Selection_Report.pdf`.
- Council roster source remains `src/data/council.ts` (66 entries), preserving source-verification flags where the report transcription is uncertain.
- Team structure from the SCMS database: Executive Council, Cultural, Sports, Technical, Social Responsibility, PR & Media, Student Welfare, Women's Representative, and Training & Placement.
- Finance workflow concepts: team budget allocation, expense ledger, receipt/reference field, pending review, recorded spend, remaining allocation, utilization, and CSV export.

## Implemented in ASTRA POINT

- Budget & Expenses now includes a team budget command center, per-team allocation, utilization, remaining balance, expense entry and review, budget request register, and combined CSV export.
- Council directory now offers roster CSV export and a link to the official source report.
- Budget allocations begin at zero because SCMS v4 does not contain verified annual monetary allocations. No amounts were invented or copied from demo requests as actual budgets.
- Existing ASTRA POINT Supabase configuration and migrations were not changed. The added finance interface currently stores prototype data in the browser's local storage and is not a production financial ledger.

## Data protection / import boundaries

- The SCMS SQLite database contains 66 user records and demo/default credentials. Those credentials, password fields, and local authentication sessions were deliberately not imported into ASTRA POINT.
- SCMS v4 is a FastAPI/SQLite app while ASTRA POINT is a React/TypeScript/Supabase app. The FastAPI backend and SQLite database were not substituted for the existing Supabase architecture.
- The official roster transcription includes uncertainty flags. Verify flagged names and class/branch associations against the signed source PDF before account provisioning or assigning permissions.

## Verification still required

Install dependencies, run `npm run build`, then test budget permissions and flows in a browser. The finance controls are a local prototype only; production use requires server-side authorization, Supabase schema/RLS design review, receipt storage, and an audit trail.
