# ASTRA POINT Roadmap

## Milestone 1 — Runnable UI foundation (this package)
Responsive dashboard, navigation, demo event/task/approval interactions, visual system and documented limitations.

## Milestone 2 — Secure foundation
Connect only to the authorized existing Supabase project; inspect schema and RLS; implement sign-in/session handling, profiles, roles and permission guards. No resets or destructive migrations.

## Milestone 3 — Council and event workflows
Council terms, committees, event proposals, review/approval, registration, attendance and audit history.

## Milestone 4 — Operations
Tasks, volunteers, budgets/expenses, documents, announcements, notifications and calendar.

## Milestone 5 — Recognition and insights
Media moderation, certificates, feedback privacy, analytics, reports and controlled exports.

## Milestone 6 — Release readiness
RLS/security tests, accessibility, mobile testing, backup/restore drill, manuals, staging and explicit production approval.

## Milestone 1A — Full management coverage prototype
Inventory, sponsor/partnership pipeline, election nomination placeholders and audit-log preview are included as UI modules. They remain mock-data-only. Before backend design, review each workflow, define authorized actors and test success/failure states. Secure elections and immutable audit records require separate threat modeling and backend implementation.
