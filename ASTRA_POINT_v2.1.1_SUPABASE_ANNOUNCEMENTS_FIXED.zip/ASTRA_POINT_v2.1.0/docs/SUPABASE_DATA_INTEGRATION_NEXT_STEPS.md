# Supabase data integration (local authentication preserved)

## UI fix in v0.16.3
The signed-in account strip is no longer fixed over the workspace header. It is in normal document flow, constrained on mobile, and its action buttons remain visible.

## Authentication boundary
ASTRA POINT local authentication remains unchanged in `src/localAuth.ts` and `src/AuthRoot.tsx`. Do not enable Supabase Auth unless explicitly requested.

## Database integration status
This package does not claim that all modules are already synced to Supabase. Current modules still contain browser-local state, prototype-only forms, and hard-coded sample lists. A real shared-data rollout needs a server-side data API/Edge Function that validates local-account sessions and enforces each role/scope before using a server-held Supabase service key. Never place a service-role key in `VITE_*` variables or browser code, and do not grant unrestricted anonymous read/write access to tables.

## Required implementation sequence
1. Add a server-side session exchange for the existing local credentials, with rate limiting and secure expiry/revocation.
2. Create normalized tables for events, tasks, approvals, certificates, budget, feedback, notices, meetings, inventory, partnerships, elections, submissions, and audit events.
3. Add database constraints, row-level security, and role/scope authorization for every read/write action.
4. Replace each module's local-only state with API-backed reads and mutations, including loading/error/retry states.
5. Configure the confirmed Supabase project URL and publishable key; keep the service-role key only in server secrets.
6. Test student, coordinator, president, approver, treasurer, and admin permissions across separate browsers/devices before production.

## Configuration
The `.env.example` file remains a placeholder. This archive has not been connected to a live Supabase project because no project URL/keys or deployed backend details were provided in this task.
