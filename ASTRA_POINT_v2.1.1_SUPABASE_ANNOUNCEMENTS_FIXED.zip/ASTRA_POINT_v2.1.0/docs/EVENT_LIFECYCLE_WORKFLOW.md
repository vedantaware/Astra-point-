# ASTRA POINT — Event Lifecycle Workflow (v0.2 demo)

## States
`Draft → Submitted → Stage 1 approved → Approved → Published → Registration closed → Completed`

Alternate paths:
- `Submitted` or `Stage 1 approved` → `Returned for revision` (requires a revision note) → `Submitted` (new 48-hour review window).
- `Submitted` or `Stage 1 approved` → `Rejected` (requires a decision reason).
- `Published` or `Registration closed` → `Cancelled`.
- Draft can be submitted for review.

## Approval rules
- Stage 1: assigned faculty coordinator / first reviewer.
- Stage 2: institutional approver when required by event policy.
- Publish is available only after both required stages.
- Production must prevent submitter self-approval and enforce permissions server-side.
- Return requires a revision note; rejection requires a reason.

## SLA and escalation
- Review deadline: 48 hours from submission.
- UI shows client-side remaining/overdue status.
- Notification intent: submission to organizer and Stage 1 reviewer; Stage 1 approval to Stage 2; final decision to organizer; reminders before deadline and escalation after expiry.
- Actual delivery and scheduled escalation are not implemented.

## Audit
The UI records transitions, actor label, timestamp and details in component memory. Production must use server-side append-only audit records with authenticated actor ID, resource ID, prior/new state, reason, timestamp, correlation ID and outcome.

## Limitations
- State resets on refresh; per-event state is not persisted.
- Event register status is not synchronized to workflow status.
- No Supabase, server authorization, notification delivery, scheduled job, transaction or durable audit storage is connected.
