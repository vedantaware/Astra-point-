# E2E acceptance checklist — v0.33.0

This is the required browser acceptance suite after `npm install` succeeds and test accounts exist. It is intentionally not marked as passed because this environment could not resolve `registry.npmjs.org` and the Supabase project currently has no Auth users.

1. Sign in as each of the ten configured roles and verify only allowed navigation appears.
2. As a student, submit an anonymous feedback response; verify `respondent_id IS NULL` and response content is not visible to that student through the client API.
3. As a student, submit an identified response; verify `respondent_id = auth.uid()` and that a closed form rejects a submission.
4. As faculty/council leadership, create and close a feedback form; open it in a student session and submit a response.
5. As a finance submitter, create an expense; verify the same account cannot approve it. Approve it from a different finance account and verify the audit log row exists.
6. As a roster manager, create a team and add an existing Auth profile; verify a student cannot edit or delete that team.
7. Schedule a meeting, record self-attendance, save minutes, and verify a stale version update is rejected.
8. Send a notification to another test account, sign in as that recipient, mark it read, reload, and verify `read_at` persists.
9. Attempt direct client `INSERT`, `UPDATE`, and `DELETE` on `astra.audit_logs`; all must be denied, while trigger-generated audit records still appear after permitted workflow changes.
10. Run `npm run build` and the browser E2E suite in a network-enabled environment. Record the exact dependency versions and test account role mapping with the release artifact.
