# ASTRA POINT — Roles and Data Model (draft)

## Status
This is a proposed access-control and schema design. The React roles screen is illustrative only. It does not enforce permissions, and the SQL migration has not been applied or verified against a Supabase project.

## Role model
Use capability-based roles plus scoped assignments. Avoid hard-coding authority from display titles alone.

- Platform Administrator: platform configuration and role assignment; not automatic business approval.
- Principal / Institutional Approver: institutional decisions explicitly delegated by college policy.
- Faculty Coordinator: review in assigned committee/department scope.
- Council President: council-term oversight and delegated council operations.
- Secretary / Event Organizer: create/edit owned drafts, submit proposals and manage authorized event operations.
- Treasurer: budget preparation/review; payment execution requires separate explicit authority.
- Committee Member / Volunteer: assigned committee information and assigned tasks.
- Student Participant: published event discovery and own registration/feedback.
- Auditor / Read-only Reviewer: explicitly granted read-only records and audit views.

A role assignment should include user_id, role_key, scope_type, scope_id, valid_from, valid_until, granted_by, revoked_at. A user can have multiple scoped assignments. The role table is not a substitute for resource-level checks.

## Event permissions
- Draft creation/edit: organizer owns the draft, or an explicitly authorized scoped role.
- Submit: authorized organizer; submission freezes or versions the submitted payload.
- Stage 1: assigned reviewer; cannot be the submitter.
- Stage 2: assigned institutional approver only where policy requires it; cannot be the submitter or prohibited conflicted reviewer.
- Return for revision: requires a reason and returns to organizer.
- Reject: terminal decision requires a reason.
- Publish: only after all required stages are approved.
- Transition to completed/cancelled: authorized event owner/reviewer according to policy, with audit reason.
- 48-hour SLA: measured by server time from submission; reminders/escalation need a scheduled server-side job.
- Every transition must be transactionally validated and audited server-side.

## Data entities
profiles, roles, role_assignments, council_terms, council_memberships, committees, committee_memberships, events, event_approvals, workflow_transitions, audit_logs, notifications, registrations, attendance, event_feedback.

## Sensitive-data principles
- Do not store passwords in application tables; use Supabase Auth.
- Do not put service-role secrets in Vite client environment variables.
- RLS should be enabled on every exposed table and default to deny.
- Users can read/update their own profile only within a safe column policy.
- Student participants should read/update their own registrations; organizers see event-scoped data only when assigned.
- Committee membership must be checked through active, dated assignments.
- Audit logs should be insert-only from trusted server-side transition functions; clients must not edit/delete them.
- Never trust a client-supplied role name, actor ID, workflow state or timestamp.

## Rollout plan
1. Inspect the target Supabase schema and Auth setup.
2. Agree role keys and event policy with the college.
3. Apply schema in a development project, not production.
4. Add RLS policies and transaction-safe transition RPC/Edge Function.
5. Test each role against allowed and denied operations.
6. Add scheduled SLA reminders/escalation and delivery logs.
7. Only then connect UI to the live backend.
