# ASTRA POINT v0.15.0 — Bug-fix report

## Fixed in this package

- Login accepts either a valid email address or the established ASTRA POINT username format. Error messages now distinguish the two login paths. Username login continues to use the synthetic `@login.astrapoint.invalid` identity created by the included admin provisioning function.
- Certificate print HTML escapes all user-controlled text before inserting it into the document, mitigating HTML/script injection through recipient, event, club, type, and reference fields.
- CSV exports now include a UTF-8 BOM, use CRLF rows, protect cells beginning with spreadsheet formula characters, append the download anchor to the document, and defer revoking the blob URL.
- Demo approval decisions are recorded in a local history key with decision, actor and timestamp before removing the item from the pending queue.
- Footer and package version labels updated to v0.15.0.

## Still requires a confirmed backend and deployment

This ZIP is a frontend prototype plus draft Supabase migrations/function. It does not yet make the Events, Tasks, Approvals, Applications, Certificates, Notices, Letters, Media, Clubs, or other module data durable/shared in Supabase. The fixes above do not turn localStorage into a secure database.

Before production use, a maintainer must confirm the intended Supabase project, review and apply migrations in a controlled environment, configure/deploy the Edge Function and secrets, bootstrap the first administrator securely, implement and test transactional workflow RPCs and RLS policies for every entity, implement forced password change/recovery/deactivation, connect real file storage and email delivery, and run full browser/role regression tests.

## Verification

- Source-level changes were inspected.
- `npm install --ignore-scripts --no-audit --no-fund` timed out in this environment. Therefore `npm run build`, lint, and browser tests could not be verified here.
- No live Supabase connection, credentials, migrations, or data were changed.
- Do not treat demo records, local approval history, or “email queued” labels as official records or delivered notifications.
