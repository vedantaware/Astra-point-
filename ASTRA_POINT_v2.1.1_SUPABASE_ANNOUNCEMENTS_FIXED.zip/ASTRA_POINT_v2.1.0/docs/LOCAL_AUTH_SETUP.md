# ASTRA POINT local login accounts

- Supabase Authentication is disabled in the app login flow.
- 66 accounts were imported from the SCMS v4 SQLite bundle, plus one ASTRA POINT administrator account.
- Full initial login IDs and unique passwords are in `ASTRA_POINT_LOCAL_LOGIN_CREDENTIALS.csv`.
- Administrator login ID: `admin.astra`; its generated password is listed in that CSV.
- This is suitable only for a private demo/prototype. Client-side authentication cannot protect production data; bundled hashes and role checks can be inspected or bypassed.
- App workspace modules and existing Supabase database calls/features were not intentionally removed or rewritten. Only authentication/account provisioning was switched to local mode.
- New accounts created from the admin panel are stored in browser localStorage on that browser/device, not shared with other users.
