# ASTRA POINT Student Portal Homepage — v0.19.0

## Approved direction implemented
- Hybrid student portal and dashboard feel.
- Cream background with wine-red accents.
- Wide responsive navigation and Student Login at the top.
- Centered hero: “Your campus. Your council. Your voice.”
- Smooth hover/scroll interactions with reduced-motion support retained.
- Public sections: Council, Events, Announcements, Student Services, Live Stats, Gallery, About, Contact.
- Existing login/authentication screen and local authentication behavior preserved.

## Data rules
- Council directory/counts use `src/data/council.ts`.
- Public events are read from the existing browser-local `astra-point-demo-events` records and filtered to `status === "Published"`.
- Public announcements are read from `astra-point-demo-announcements` and require `status === "Published"`, `publicPortal === true`, and `audience === "Student Council Portal (public)"`.
- Event/announcement changes trigger a refresh event for the public feed.
- The current app is local-prototype mode. This public feed does not query Supabase. No Supabase schema, remote records, credentials, authentication settings, or existing council roster were changed.
- The gallery shows a truthful empty state until real/approved campus images are available. Brand logos are not misrepresented as campus photographs.
- Contact shows a truthful message until an official public contact channel is supplied; no email address is invented.
- Student service cards continue to route through the existing login flow.

## Verification
- TS/TSX syntax transpilation passed for all source files.
- CSS brace count is balanced.
- Full TypeScript project build and interactive browser/device tests could not be run because dependencies are absent and installation previously timed out.
