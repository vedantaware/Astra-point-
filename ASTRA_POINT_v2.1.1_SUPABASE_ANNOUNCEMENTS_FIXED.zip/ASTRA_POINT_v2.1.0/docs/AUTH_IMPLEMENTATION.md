# ASTRA POINT Username Authentication — implementation draft

## Inspected backend
The available Supabase account has project ref `jdsqcbishfbjjsxipicm`, status ACTIVE_HEALTHY, and existing populated `profiles`, `portal_data`, Axial and music/Naadsetu tables plus existing `provision-users` and `admin-create-hod` Edge Functions. It is not named ASTRA POINT and is shared with other application schemas. Do not apply this migration or deploy this function until the owner confirms that this is the intended backend. This package did not change that live project.

## Sign-in design
Supabase Auth has no native username/password endpoint. This implementation maps a normalized unique username to a synthetic Auth email `${username}@login.astrapoint.invalid`. This address is an internal login alias and is not an email address for contact or recovery. Sign-in uses Supabase Auth password verification and then reads the user's active `astra_access_profiles` row.

Username constraints: 3–32 lowercase ASCII letters, numbers, dot, underscore, hyphen; unique, normalized. No public registration. The browser only has the publishable/anon key. The service-role key must exist only in Edge Function secrets.

## Account provisioning
`supabase/functions/astra-admin-users/index.ts` checks the authenticated token and requires an active `platform_admin` profile server-side. It creates Auth users and the profile row atomically in application logic, cleaning up the new Auth user if profile insert fails. It logs account creation when audit insert succeeds. It does not expose platform-admin creation through the regular endpoint. Initial passwords are entered by an administrator and never persisted in ASTRA tables; password reset/first-login rotation still needs a verified user recovery flow before production.

## Authorization / RLS
Migration creates isolated `astra_*` tables and policies. It does not modify existing `profiles`, `portal_data`, Axial or Naadsetu tables. Browser writes to role profiles, approvals and audit logs are intentionally denied. Event transition writes require a trusted transactional workflow function, which is not yet implemented. Do not claim production security until RLS policies and negative permission tests pass.

## First administrator bootstrap
No default administrator or credentials are created. After the backend is confirmed, an operator must create/verify the first account through a one-time, audited server-side bootstrap process. Never place service-role keys in Vite variables or commit secrets.

## Test checklist
1. Anonymous user cannot select `astra_access_profiles`, events, approvals, or audit records.
2. Authenticated user can select only their own access profile; admin can list profiles through a server function only.
3. Non-admin calling `astra-admin-users` receives 403.
4. Duplicate username fails and newly created Auth user is cleaned up if profile insert fails.
5. Invalid username and password fail; disabled profile cannot enter workspace.
6. Committee/student cannot create or publish events without allowed role/scope.
7. Organizer cannot change status from draft/returned directly to approved/published.
8. Client cannot write approvals or audit logs.
9. Registration user cannot read another participant's registration.
10. Existing non-ASTRA tables, rows and policies remain unchanged.

## Bootstrap blocker
The package intentionally creates no first administrator, username, password, or verified identity. Before any user can sign in, the first platform administrator must be provisioned through a separately controlled operator-only process using Supabase Auth Admin API and inserted into `astra_access_profiles`. Do not create this user with browser SQL or expose the service-role key. A one-time bootstrap endpoint guarded by a high-entropy secret or a trusted operator script should be added and removed/disabled after use.

## Deployment gate
The available Supabase project is an active shared project with pre-existing application data and policies. No migration, function deployment, Auth-user creation, or policy modification was executed against it. Confirm the target project explicitly before applying this additive schema. `npm install` did not complete in the current environment, so TypeScript/Vite build is not verified.


## v0.16.1 local-auth override

The current frontend login uses `src/localAuth.ts` and does not call Supabase Auth. Initial accounts are seeded from the SCMS v4 user roster; see `ASTRA_POINT_LOCAL_LOGIN_CREDENTIALS.csv`. Supabase database integrations and migration files are retained, but local login does not create Supabase Auth users or database profiles. This is a demo-only mode, not a production security boundary.
