# ASTRA POINT v0.18.0 — Clean Data & Student Portal

## Pre-login public portal
- Replaced the pre-login public page with a student-focused landing experience.
- Added public navigation for home, council directory, events, announcements, and student services.
- Added search across the existing council roster (name, role, committee, branch).
- Student team cards use `src/data/council.ts`, preserving existing council data.
- Public events and announcements have honest empty states; no sample events/notices are fabricated.
- Removed public sign-up form that only wrote local demo applications. Students can use the existing sign-in flow; public account creation remains disabled until a verified backend workflow exists.

## Demo-data cleanup
- Removed seeded events, tasks, approvals, meetings, budget requests/allocations, notices, media assets, feedback forms, inventory assets, partnership rows, election nominations, ranking rows, hall-of-fame records, club rows, submissions, certificate batches/records, and audit preview entries.
- Removed the static sample registration chart and hard-coded sample analytics totals.
- Added a one-time browser cleanup for `astra-point-demo-*`, `astra-demo-*`, and `astra-point-scms-budget-*` keys.

## Explicitly preserved
- Local authentication account store and session keys.
- Existing council roster and local source files.
- Supabase client/configuration, `.env.example`, migrations, and Edge Function source.
- Theme and per-role dashboard layout preferences.
- All existing module components and routes.

## Data safety boundary
The cleanup operates only on browser-local keys with the named demo prefixes. It does **not** connect to, delete, or mutate a Supabase database. Existing local authentication accounts are preserved. No remote records were inspected or changed.

## Verification
- TS/TSX syntax transpilation: passed.
- ZIP integrity: to be checked after packaging.
- Production build, type-check with installed React dependencies, browser interactions, and responsive device testing: not verified because `npm install` timed out and dependencies are unavailable.
