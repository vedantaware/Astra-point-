# ASTRA POINT v0.33.0 — role and workflow verification

## Implemented relational paths

- Teams and roster membership: `astra.teams`, `astra.team_members`, `astra.profiles`
- Budget allocations and expense review: `astra.budgets`, `astra.expenses`
- Meetings and minutes: `astra.meetings`
- Self attendance: `astra.attendance`
- Feedback form authoring and response submission: `astra.feedback_forms`, `astra.feedback_responses`
- Inbox and read state: `astra.notifications`
- Persistent audit trail: `astra.audit_logs`, written by database triggers

## Permission matrix based on the live RLS policies

| Role | Team management | Budget read | Budget allocation | Expense review | Meeting write | Feedback form management | Raw feedback responses | Audit log read |
|---|---|---|---|---|---|---|---|---|
| `platform_admin` | Yes | Yes | Yes | Yes, not own expense | Yes | Yes | Yes | Yes |
| `institution_approver` | No | Yes | No | Yes, not own expense | No | No | No | Yes |
| `faculty_coordinator` | Yes | No (policy) | No | No (policy) | Yes | Yes | Yes | No |
| `council_president` | Yes | Yes | Yes | Yes, not own expense | Yes | Yes | Yes | No |
| `event_organizer` | No | No | No | No | No | No | Own identified response only | No |
| `treasurer` | No | Yes | Yes | Yes, not own expense | No | No | No | No |
| `committee_member` | No | No | No | Own submitted expenses only | No | No | Own identified response only | No |
| `club_lead` | No | No | No | Own submitted expenses only | No | No | Own identified response only | No |
| `student_participant` | No | No | No | Own submitted expenses only | No | No | Own identified response only | No |
| `auditor_readonly` | No | Yes | No | Read-only | No | No | No | Yes |

The table reflects the database policies inspected for the `astra` schema; it is not a substitute for testing with real authenticated sessions. UI role switching is explicitly a demo-only affordance and is not an authorization control.

## Automated checks

Run `npm run test:permissions` to validate all ten UI role keys, relational data functions, and key RLS migration invariants. This is a static policy-regression check, not an impersonated-session test.

## Live test blockers at the time of this package build

- The Supabase project had **zero Auth users and zero `astra.profiles` rows** when checked, so there are no real role accounts with which to execute a signed-in RLS matrix. Sign-up provisions a `student_participant` profile through the existing Auth trigger; privileged role tests require test accounts provisioned by the administrator.
- Frontend dependencies were not available in the local npm cache and npm registry installation timed out. Therefore the production bundle and browser E2E suite could not be run in this environment. Run `npm install`, `npm run build`, then browser E2E tests after dependencies and role test accounts are available.
