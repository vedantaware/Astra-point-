# ASTRA POINT v0.21.0 — Clubs Directory

Added a public Clubs section with user-provided logos and supplied leadership details for AWS SBG and FORGE CODING CLUB. NAADSETU is listed as Launching soon; no team names were fabricated. Club information is stored in `src/data/clubs.ts`. Assets are in `public/clubs/`.

No Supabase schema, remote data, authentication, or existing council records were changed. The directory is static project data until an approved live data workflow is specified.
