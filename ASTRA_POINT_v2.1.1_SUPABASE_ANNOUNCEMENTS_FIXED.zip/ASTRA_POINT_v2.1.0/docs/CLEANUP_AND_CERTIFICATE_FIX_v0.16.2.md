# ASTRA POINT v0.16.2 — Demo Cleanup & Certificate Permissions

## Changes
- Removed the password-free demo workspace/role-switch entry from the login screen.
- Removed seeded event, task, approval, and chart metrics from initial application state.
- Clear browser localStorage keys containing `demo` on workspace initialization; local account/session and theme keys are retained.
- Removed fabricated sample certificate recipient identities. Certificate batches cannot be issued until verified recipient records are supplied.
- Student Participant, Club Lead, Committee Member, and Event Organizer roles cannot access certificate creation/approval/issuance; only Platform Administrator, Institutional Approver, Faculty Coordinator, and Council President roles are allowed in the UI.
- Removed Certificates from Student Participant and Event Organizer navigation.
- Kept Supabase configuration/database files unchanged; local authentication remains selected.

## Important limits
- This is a client-side prototype. UI role checks are not a security boundary against a malicious user. Production issuance must enforce permissions server-side.
- Clearing browser `*demo*` keys is local to the browser running this version; it does not delete any Supabase/database records or clear other devices.
- Other modules may still contain static placeholder labels or sample configurations. Verify each module and perform a production build before deployment.
- Full TypeScript build and live browser regression tests have not been run in this environment.
