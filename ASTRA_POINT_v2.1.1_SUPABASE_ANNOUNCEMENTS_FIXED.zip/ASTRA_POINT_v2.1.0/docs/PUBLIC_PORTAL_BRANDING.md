# ASTRA POINT Public Portal Branding

- Public landing page now follows the approved minimal pastel reference: rounded header, split hero, blank team-photo area, announcement cards and responsive layout.
- ASTRA mark is derived from the user-supplied ASTRA logo image.
- Student Council crest is cropped from the user-supplied Siddhant College Student Council image.
- No people or council member names are fabricated in the hero. The team photo area is intentionally blank.
- Statistics use non-numeric labels rather than invented figures.
- Announcement list only displays records explicitly published to the public Student Council Portal.
- This remains a frontend prototype; public permissions and persistent data require server enforcement in the later backend phase.
