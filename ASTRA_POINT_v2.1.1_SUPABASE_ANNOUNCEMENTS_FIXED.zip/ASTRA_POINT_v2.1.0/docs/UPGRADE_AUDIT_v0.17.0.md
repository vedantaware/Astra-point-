# ASTRA POINT v0.17.0 — Upgrade audit map

## Existing modules preserved
- Overview / role-specific dashboard
- Events and event lifecycle demo
- Council directory and committees
- Tasks and approvals
- Student verification applications
- Budget, notices, meetings, roles
- Media, certificates, feedback, reports
- Inventory, partnerships, elections, audit
- Letter & PDF Studio
- Student portal: rankings, hall of fame, clubs, submissions, profile
- Public student council portal
- Existing authentication shell, Supabase client, SQL migrations, and Edge Function source

## Added / upgraded in this iteration
- Global command palette (`Ctrl/⌘ K`) with role-filtered page navigation and search across events, tasks, and council people
- Calendar workspace with timeline and list modes for events and task due dates
- Actionable demo notification centre based on pending approvals, incomplete tasks, and events in review
- Browser online/offline indicator
- First-run realistic seed records for events, tasks, and approvals
- Removed destructive startup cleanup that deleted localStorage keys containing `demo`
- Replaced fabricated overview count adjustments with current record-derived metrics
- Responsive and reduced-motion styling for new surfaces

## Explicitly not changed
- No Supabase migration applied or generated
- No remote database queried or mutated
- No credentials or `.env` files overwritten
- No real council data intentionally deleted
- No new production backend claims: local demo state remains local where not explicitly integrated

## Verification
- Static review: performed on the source tree
- Build/type-check: pending dependency availability and command execution
- Browser interaction, accessibility audit, mobile-device test, and live Supabase/RLS validation: not verified in this package
