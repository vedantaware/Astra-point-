# ASTRA POINT Phase 2 — Frontend Prototype

## Agreed design direction
- Minimal visual system, light/dark switch, sidebar layout, split-screen login.
- Role-specific dashboard and role-filtered navigation.
- Responsive layouts and balanced information density.
- Council directory as profile cards with search and filters.
- Event lifecycle workflow with revision/rejection notes, two-stage review presentation, 48-hour SLA display, and local audit timeline.
- English UI, subtle transitions, reduced-motion support, in-app notification center, and email preview UI.

## Interactive prototype coverage
- Login screen: live username/password flow is prepared for Supabase configuration. When no Supabase URL/key are configured, a clearly labelled demo-role selector opens the mock workspace without creating an account.
- Dashboard: role-specific navigation and summary cards.
- Events: create local draft, search/filter, view lifecycle transitions, capture demo decision reasons and review history.
- Council: searchable/filterable profile cards based on the existing transcribed council source. Rows with ambiguous source text retain verification flags.
- Committees: create local mock committee cards.
- Tasks: create tasks, filter open/completed, and toggle completion.
- Approvals: local approve/return interaction.
- Budget: create request drafts, submit to demo review, and mark demo approval. No payment processing.
- Meetings: create meetings, open details, and mark attendance/minutes in local state.
- Notices: draft/publish mock notices, select audiences, and view email previews. No message is delivered.
- Media: add asset metadata to a review queue and approve/remove local records. File chooser reads filename only; no upload is performed.
- Certificates: create draft batches and mark them issued in demo state. No certificates are generated or verified.
- Feedback: create/close forms and view a non-submitting preview. No responses are persisted.
- Reports: download sample CSV templates clearly labelled as demo data.
- Roles: view proposed roles, permissions and guardrail switches. These switches are not security controls.
- Export: downloads a demo CSV, never a verified institutional report.

## Boundaries
- All new module interactions are in-memory browser state and are lost on refresh.
- No database migrations were applied and no live Supabase data or accounts were changed.
- Frontend role filtering is not an authorization boundary. Live security requires server-side checks and RLS.
- Email, real file storage, real calendar integration, certificate generation, verified report exports, and live persistence are not connected.

## Validation status
- TypeScript/JSX source was syntax-transpiled successfully with the globally available TypeScript transpiler.
- Full dependency installation and production build remain unverified because npm registry dependencies could not be installed in this environment. Do not label this package production-ready until dependencies install, `npm run build` passes, and browser/device interaction tests are completed.

## Expanded full-management-system prototype (v0.9)
- Added Inventory for asset register, location, custodian/status tracking.
- Added Partnerships for sponsor outreach pipeline and commitment tracking.
- Added Elections workspace for nomination review placeholders and voting-window UI (no real voting).
- Added Audit workspace with explicitly illustrative activity examples and sample export.
- Added these modules to role-filtered navigation and page descriptions.
- These screens use local demo state only. They do not implement live asset custody, sponsor communication, secret ballot elections or tamper-resistant audit logs.
