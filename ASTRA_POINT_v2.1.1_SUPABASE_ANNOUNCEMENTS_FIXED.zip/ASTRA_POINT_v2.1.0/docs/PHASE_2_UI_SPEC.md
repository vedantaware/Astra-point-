# ASTRA POINT Phase 2 UI/UX Specification

## Approved direction
- Minimal, professional visual style
- Dark and light themes with a switcher
- Sidebar navigation; responsive collapse on small screens
- Split-screen login
- Role-specific dashboards and role-aware navigation
- Balanced information density
- Council member profile cards and search/filter directory
- Event workflow pipeline with supporting list/calendar views
- In-app notification center and email delivery settings/previews planned
- English interface
- Subtle transitions and reduced-motion support
- All major modules represented in the first frontend prototype

## Screen inventory
1. **Access:** username/password login, invalid/inactive account, loading, configuration warning, account administration for the authorized platform administrator, and planned password reset screens.
2. **Shared shell:** role-filtered sidebar, header, search, theme switcher, notification center, user menu/sign-out, breadcrumbs, responsive navigation, empty/error/loading/permission states.
3. **Dashboards:** platform administrator, institutional approver, faculty coordinator, council president, event organizer, treasurer, committee member, student participant, and auditor/read-only reviewer.
4. **Council:** term overview, profile cards, member details, leadership positions, committees, assignments and member administration.
5. **Events:** pipeline, proposal editor, event detail, review workspace, revision/rejection reason, approval history, publication, registration, attendance/check-in, completion report, closure, calendar/list views.
6. **Tasks:** assignment, ownership, priority, due dates, status and volunteer coordination.
7. **Meetings:** scheduling, agenda, attendance, minutes and decisions.
8. **Approvals:** queue, reviewer decision, revision/rejection reason, history and deadline display.
9. **Budget:** budget requests, expenses, receipts, review history and summaries.
10. **Notices:** draft, audience preview, in-app/email delivery preview and status.
11. **Media:** uploads, asset review and event gallery.
12. **Certificates:** eligibility, batch creation, issue/verification states.
13. **Feedback:** form and case tracking with confidentiality boundaries.
14. **Reports:** event, participation, attendance, finance and feedback reporting; export preview.
15. **Roles/admin:** role descriptions, account management, organization settings, workflow configuration and audit-log viewing.

## Event workflow presentation
Draft → Submitted → Faculty coordinator review → (Revision requested / Rejected / Recommended) → Authorized final approver → (Revision requested / Rejected / Approved) → Ready to publish → Published and registration open → Attendance/check-in → Completion report → Closed.

The interface should show status, responsible reviewer, decision history, revision reason, deadline and next permitted action. A 48-hour review target is displayed as a workflow requirement; actual timers, notifications and escalations require backend support.

## Visual and interaction rules
- Neutral palette, clear type hierarchy, restrained borders and consistent spacing.
- Status labels use consistent meanings and visual treatment.
- Forms provide validation, required-field indicators and unsaved-change warnings.
- Confirm consequential actions and expose success/error feedback.
- Search, filters, sorting and pagination where useful.
- Keyboard access, visible focus, labels, sufficient contrast and reduced-motion support.
- Mock data is labeled as demo data; no unverified roster information may be presented as verified.

## Out of scope until later phases
No database migrations, account provisioning, storage configuration, email delivery, live persistence, or changes to existing Supabase data during this UI phase. Frontend role filtering is not a security boundary. Production readiness requires dependency installation, build and browser testing, server-side authorization, and live permission tests.

## Public Student Council Portal and announcements (implementation update)

- Unauthenticated visitors land on the public Student Council Portal; a dedicated button opens the separate member login screen.
- Public page sections: home hero, public announcements, event listing placeholder, council directory placeholder, and member login.
- Only records with `status === "Published"`, `publicPortal === true`, and audience exactly `Student Council Portal (public)` are rendered as public announcements.
- Internal audiences remain private in the intended product: My team / committee, All council leads, and Every student council member.
- Announcement composer supports audience selection, channel preview, priority, visibility duration, acknowledgement requirement, search, status filter, and explicit public publication warning.
- Public portal and workspace demo share a browser-local mock announcement store for prototype review. This is not secure storage and not a production publishing mechanism.
- Public publishing controls are only shown in the prototype for platform administrator, institutional approver, faculty coordinator, and council president roles. This UI rule is not a substitute for server-side authorization.
- No database schema, Supabase migration, Edge Function, or live data was modified for this work.
