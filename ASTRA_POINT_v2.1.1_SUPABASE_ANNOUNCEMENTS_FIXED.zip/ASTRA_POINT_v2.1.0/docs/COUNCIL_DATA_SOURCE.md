# ASTRA POINT — Council Data Source

Source: uploaded `Scan 21 Aug 2026(1).pdf`, titled *Selection Committee Report — Student Council 2026-27*, Siddhant College of Engineering, dated 21 August 2026.

The source transcription is implemented in `src/data/council.ts` and displayed in the Council directory. The scan contains duplicated/misaligned serial numbers in the Student Welfare / Women's Representative section, and several OCR-sensitive names/class-branch cells. The app uses stable internal row identifiers, not the report's printed serials, and flags uncertain transcriptions where identified.

Before using this data for account provisioning, permissions, formal communication or certificates, verify flagged names and class/branch values against the original signed scan. No login credentials are generated. This data is embedded in the frontend source; it is not connected to Supabase or access-controlled yet.
