create or replace function astra.bump_version_and_audit()
returns trigger language plpgsql security definer set search_path = astra, pg_temp as $$
declare v_actor uuid := auth.uid(); v_entity_id text; v_action text; v_details jsonb;
begin
  if tg_op = 'UPDATE' then
    if to_jsonb(new) ? 'version' then new.version := coalesce(old.version, 0) + 1; end if;
    if to_jsonb(new) ? 'updated_at' then new.updated_at := now(); end if;
    v_entity_id := coalesce(to_jsonb(new)->>'id', to_jsonb(new)->>'user_id');
    v_action := lower(tg_table_name) || '.updated';
    v_details := jsonb_build_object('changed_fields',(select coalesce(jsonb_agg(fields.key), '[]'::jsonb) from jsonb_object_keys(to_jsonb(new)) as fields(key) where to_jsonb(new)->fields.key is distinct from to_jsonb(old)->fields.key and fields.key not in ('updated_at','version')));
  elsif tg_op = 'INSERT' then
    v_entity_id := coalesce(to_jsonb(new)->>'id', to_jsonb(new)->>'user_id'); v_action := lower(tg_table_name) || '.created';
    v_details := jsonb_build_object('record', jsonb_strip_nulls(jsonb_build_object('id',v_entity_id)));
  else
    v_entity_id := coalesce(to_jsonb(old)->>'id', to_jsonb(old)->>'user_id'); v_action := lower(tg_table_name) || '.deleted';
    v_details := jsonb_build_object('record', jsonb_strip_nulls(jsonb_build_object('id',v_entity_id)));
  end if;
  insert into astra.audit_logs(actor_id,action,entity_type,entity_id,details) values(v_actor,v_action,tg_table_name,v_entity_id,coalesce(v_details,'{}'::jsonb));
  if tg_op='DELETE' then return old; end if; return new;
end; $$;
revoke all on function astra.bump_version_and_audit() from public,anon,authenticated;
