-- Public, published sports team roster for the ASTRA POINT Home Page.
create table if not exists public.campus_sports_team_members (
  id uuid primary key default gen_random_uuid(),
  team_name text not null,
  sport text not null,
  member_name text not null,
  class_name text not null,
  sort_order integer not null default 0,
  is_published boolean not null default true,
  created_at timestamptz not null default now()
);
alter table public.campus_sports_team_members enable row level security;
drop policy if exists campus_sports_team_members_public_read on public.campus_sports_team_members;
create policy campus_sports_team_members_public_read
  on public.campus_sports_team_members for select to anon, authenticated
  using (is_published = true);
grant select on public.campus_sports_team_members to anon, authenticated;
grant insert, update, delete on public.campus_sports_team_members to authenticated;
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='campus_sports_team_members') then
    alter publication supabase_realtime add table public.campus_sports_team_members;
  end if;
exception when undefined_object then null; end $$;
