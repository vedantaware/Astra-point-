-- ASTRA POINT username auth: additive isolated tables only. Review before applying.
create extension if not exists pgcrypto;
create table if not exists public.astra_access_profiles (
 user_id uuid primary key references auth.users(id) on delete cascade,
 username text not null unique,
 display_name text not null,
 role_key text not null check(role_key in ('platform_admin','institution_approver','faculty_coordinator','council_president','event_organizer','treasurer','committee_member','student_participant','auditor_readonly')),
 active boolean not null default true,
 scope_type text check(scope_type is null or scope_type in ('platform','institution','council_term','committee','department','event')),
 scope_id uuid,
 must_change_password boolean not null default true,
 created_by uuid references auth.users(id),
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now(),
 constraint astra_username_format check(username=lower(username) and username ~ '^[a-z0-9][a-z0-9._-]{2,31}$')
);
create index if not exists astra_access_profiles_role_idx on public.astra_access_profiles(role_key,active);
create table if not exists public.astra_council_terms (id uuid primary key default gen_random_uuid(),institution_name text not null,term_name text not null,starts_on date,ends_on date,status text not null default 'draft' check(status in ('draft','active','archived')),source_document text,created_at timestamptz not null default now(),check(ends_on is null or starts_on is null or ends_on>=starts_on));
create table if not exists public.astra_committees (id uuid primary key default gen_random_uuid(),council_term_id uuid references public.astra_council_terms(id) on delete restrict,committee_key text not null,name text not null,is_active boolean not null default true,created_at timestamptz not null default now(),unique(council_term_id,committee_key));
create table if not exists public.astra_council_memberships (id uuid primary key default gen_random_uuid(),council_term_id uuid not null references public.astra_council_terms(id) on delete restrict,profile_user_id uuid references auth.users(id) on delete set null,source_name text not null,role_title text not null,class_name text,branch_or_department text,membership_type text not null check(membership_type in ('student','faculty')),verification_status text not null default 'needs_review' check(verification_status in ('verified','needs_review','corrected')),source_notes text,created_at timestamptz not null default now());
create table if not exists public.astra_committee_memberships (id uuid primary key default gen_random_uuid(),committee_id uuid not null references public.astra_committees(id) on delete cascade,user_id uuid references auth.users(id) on delete set null,role_title text not null default 'Committee Member',valid_from date,valid_until date,created_at timestamptz not null default now(),check(valid_until is null or valid_from is null or valid_until>=valid_from));
create table if not exists public.astra_events (id uuid primary key default gen_random_uuid(),event_code text unique,title text not null,description text not null default '',category text not null,organizer_user_id uuid not null references auth.users(id),committee_id uuid references public.astra_committees(id) on delete set null,starts_at timestamptz,ends_at timestamptz,venue text,capacity integer check(capacity is null or capacity>=0),status text not null default 'draft' check(status in ('draft','submitted','stage1_approved','approved','returned_for_revision','rejected','published','registration_closed','completed','cancelled')),requires_stage2 boolean not null default true,submitted_at timestamptz,review_due_at timestamptz,published_at timestamptz,created_at timestamptz not null default now(),updated_at timestamptz not null default now(),check(ends_at is null or starts_at is null or ends_at>=starts_at));
create table if not exists public.astra_event_approvals (id uuid primary key default gen_random_uuid(),event_id uuid not null references public.astra_events(id) on delete cascade,stage smallint not null check(stage in (1,2)),reviewer_user_id uuid not null references auth.users(id),decision text not null default 'pending' check(decision in ('pending','approved','returned_for_revision','rejected')),decision_reason text,decided_at timestamptz,due_at timestamptz,created_at timestamptz not null default now(),unique(event_id,stage),check(decision='pending' or decided_at is not null),check(decision not in ('returned_for_revision','rejected') or length(trim(coalesce(decision_reason,'')))>0));
create table if not exists public.astra_audit_logs (id uuid primary key default gen_random_uuid(),actor_user_id uuid references auth.users(id),action_key text not null,resource_type text not null,resource_id uuid,previous_value jsonb,new_value jsonb,reason text,request_id text,occurred_at timestamptz not null default now());
create table if not exists public.astra_notifications (id uuid primary key default gen_random_uuid(),recipient_user_id uuid not null references auth.users(id) on delete cascade,event_id uuid references public.astra_events(id) on delete cascade,notification_type text not null,payload jsonb not null default '{}'::jsonb,scheduled_for timestamptz not null default now(),sent_at timestamptz,delivery_status text not null default 'queued' check(delivery_status in ('queued','sent','failed','cancelled')),attempts integer not null default 0,last_error text,created_at timestamptz not null default now());
create table if not exists public.astra_event_registrations (id uuid primary key default gen_random_uuid(),event_id uuid not null references public.astra_events(id) on delete cascade,participant_user_id uuid not null references auth.users(id) on delete cascade,status text not null default 'registered' check(status in ('registered','waitlisted','cancelled','attended','no_show')),registered_at timestamptz not null default now(),unique(event_id,participant_user_id));
create or replace function public.astra_is_admin() returns boolean language sql stable security definer set search_path=public,pg_temp as $$ select exists(select 1 from public.astra_access_profiles p where p.user_id=auth.uid() and p.active and p.role_key='platform_admin') $$;
create or replace function public.astra_has_role(roles text[]) returns boolean language sql stable security definer set search_path=public,pg_temp as $$ select exists(select 1 from public.astra_access_profiles p where p.user_id=auth.uid() and p.active and p.role_key=any(roles)) $$;
revoke all on function public.astra_is_admin() from public,anon; grant execute on function public.astra_is_admin() to authenticated;
revoke all on function public.astra_has_role(text[]) from public,anon; grant execute on function public.astra_has_role(text[]) to authenticated;
alter table public.astra_access_profiles enable row level security;
alter table public.astra_council_terms enable row level security;
alter table public.astra_committees enable row level security;
alter table public.astra_council_memberships enable row level security;
alter table public.astra_committee_memberships enable row level security;
alter table public.astra_events enable row level security;
alter table public.astra_event_approvals enable row level security;
alter table public.astra_audit_logs enable row level security;
alter table public.astra_notifications enable row level security;
alter table public.astra_event_registrations enable row level security;
drop policy if exists astra_profile_read_self_or_admin on public.astra_access_profiles;
create policy astra_profile_read_self_or_admin on public.astra_access_profiles for select to authenticated using(user_id=auth.uid() or public.astra_is_admin());
-- No browser write policies on access profiles. The service-role Edge Function provisions users.
drop policy if exists astra_terms_read_authenticated on public.astra_council_terms;
create policy astra_terms_read_authenticated on public.astra_council_terms for select to authenticated using(public.astra_has_role(array['platform_admin','institution_approver','faculty_coordinator','council_president','event_organizer','treasurer','committee_member','student_participant','auditor_readonly']));
drop policy if exists astra_terms_admin_write on public.astra_council_terms;
create policy astra_terms_admin_write on public.astra_council_terms for all to authenticated using(public.astra_is_admin()) with check(public.astra_is_admin());
drop policy if exists astra_committees_read_authenticated on public.astra_committees;
create policy astra_committees_read_authenticated on public.astra_committees for select to authenticated using(public.astra_has_role(array['platform_admin','institution_approver','faculty_coordinator','council_president','event_organizer','treasurer','committee_member','student_participant','auditor_readonly']));
drop policy if exists astra_committees_admin_write on public.astra_committees;
create policy astra_committees_admin_write on public.astra_committees for all to authenticated using(public.astra_is_admin()) with check(public.astra_is_admin());
drop policy if exists astra_events_read_scoped on public.astra_events;
create policy astra_events_read_scoped on public.astra_events for select to authenticated using(status='published' or organizer_user_id=auth.uid() or public.astra_is_admin() or public.astra_has_role(array['institution_approver','auditor_readonly']));
drop policy if exists astra_events_create_own on public.astra_events;
create policy astra_events_create_own on public.astra_events for insert to authenticated with check(organizer_user_id=auth.uid() and public.astra_has_role(array['event_organizer','council_president','faculty_coordinator','platform_admin']));
drop policy if exists astra_events_update_own_draft on public.astra_events;
create policy astra_events_update_own_draft on public.astra_events for update to authenticated using(organizer_user_id=auth.uid() and status in ('draft','returned_for_revision')) with check(organizer_user_id=auth.uid() and status in ('draft','returned_for_revision'));
drop policy if exists astra_events_admin_all on public.astra_events;
create policy astra_events_admin_all on public.astra_events for all to authenticated using(public.astra_is_admin()) with check(public.astra_is_admin());
drop policy if exists astra_approvals_read_assigned on public.astra_event_approvals;
create policy astra_approvals_read_assigned on public.astra_event_approvals for select to authenticated using(reviewer_user_id=auth.uid() or public.astra_is_admin() or public.astra_has_role(array['institution_approver','auditor_readonly']));
-- No client-side approval write policies until a transaction-safe trusted workflow function is deployed.
drop policy if exists astra_audit_read_admin_or_auditor on public.astra_audit_logs;
create policy astra_audit_read_admin_or_auditor on public.astra_audit_logs for select to authenticated using(public.astra_is_admin() or public.astra_has_role(array['auditor_readonly']));
-- No client insert/update/delete on audit logs.
drop policy if exists astra_notifications_read_own on public.astra_notifications;
create policy astra_notifications_read_own on public.astra_notifications for select to authenticated using(recipient_user_id=auth.uid() or public.astra_is_admin());
drop policy if exists astra_registrations_read_own_or_admin on public.astra_event_registrations;
create policy astra_registrations_read_own_or_admin on public.astra_event_registrations for select to authenticated using(participant_user_id=auth.uid() or public.astra_is_admin());
drop policy if exists astra_registrations_insert_own on public.astra_event_registrations;
create policy astra_registrations_insert_own on public.astra_event_registrations for insert to authenticated with check(participant_user_id=auth.uid() and public.astra_has_role(array['student_participant']));
-- No first admin seeded. Bootstrap only after project and first admin identity are verified.
