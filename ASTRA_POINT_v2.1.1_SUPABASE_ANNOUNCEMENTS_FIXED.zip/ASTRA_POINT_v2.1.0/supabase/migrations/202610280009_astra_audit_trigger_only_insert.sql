drop policy if exists audit_logs_insert_authenticated on astra.audit_logs;
