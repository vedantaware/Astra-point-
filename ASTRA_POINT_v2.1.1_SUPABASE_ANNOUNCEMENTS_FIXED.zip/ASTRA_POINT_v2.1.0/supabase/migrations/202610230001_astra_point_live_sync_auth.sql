create extension if not exists pgcrypto;
create table if not exists public.astra_user_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text not null default '',
  role_key text not null default 'student_participant' check (role_key in ('platform_admin','institution_approver','faculty_coordinator','council_president','event_organizer','treasurer','committee_member','club_lead','student_participant','auditor_readonly')),
  department text, class_name text, branch text,
  active boolean not null default true,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create or replace function public.astra_handle_new_user()
returns trigger language plpgsql security definer set search_path=public,auth,pg_temp as $$
declare v_username text; v_name text;
begin
 v_username:=nullif(lower(trim(coalesce(new.raw_user_meta_data->>'username',''))),'');
 v_name:=nullif(trim(coalesce(new.raw_user_meta_data->>'display_name','')),'');
 if v_username is null then v_username:=split_part(new.email,'@',1); end if;
 if v_name is null then v_name:=v_username; end if;
 insert into public.astra_user_profiles(user_id,username,display_name,role_key) values(new.id,v_username,v_name,'student_participant')
 on conflict(user_id) do update set username=coalesce(public.astra_user_profiles.username,excluded.username),display_name=coalesce(nullif(public.astra_user_profiles.display_name,''),excluded.display_name);
 return new;
end $$;
drop trigger if exists astra_auth_user_created on auth.users;
create trigger astra_auth_user_created after insert on auth.users for each row execute function public.astra_handle_new_user();
create table if not exists public.astra_app_state (
 scope_key text primary key, state_key text not null, owner_id uuid references auth.users(id) on delete cascade,
 is_global boolean not null default false, payload jsonb not null default 'null'::jsonb,
 updated_by uuid references auth.users(id) on delete set null, updated_at timestamptz not null default now(),
 check ((is_global and owner_id is null) or (not is_global and owner_id is not null))
);
create index if not exists astra_app_state_owner_idx on public.astra_app_state(owner_id,state_key);
create index if not exists astra_app_state_global_idx on public.astra_app_state(state_key) where is_global;
create or replace function public.astra_can_manage_shared_state()
returns boolean language sql stable security definer set search_path=public,pg_temp as $$
 select exists(select 1 from public.astra_user_profiles p where p.user_id=auth.uid() and p.active and p.role_key in ('platform_admin','institution_approver','faculty_coordinator','council_president','event_organizer','treasurer','committee_member','club_lead'))
$$;
create or replace function public.astra_is_platform_admin()
returns boolean language sql stable security definer set search_path=public,pg_temp as $$
 select exists(select 1 from public.astra_user_profiles p where p.user_id=auth.uid() and p.active and p.role_key='platform_admin')
$$;
revoke all on function public.astra_can_manage_shared_state() from public,anon;
grant execute on function public.astra_can_manage_shared_state() to authenticated;
revoke all on function public.astra_is_platform_admin() from public,anon;
grant execute on function public.astra_is_platform_admin() to authenticated;
alter table public.astra_user_profiles enable row level security;
alter table public.astra_app_state enable row level security;
drop policy if exists astra_user_profiles_select_self_or_admin on public.astra_user_profiles;
create policy astra_user_profiles_select_self_or_admin on public.astra_user_profiles for select to authenticated using(user_id=auth.uid() or public.astra_is_platform_admin());
drop policy if exists astra_user_profiles_update_self on public.astra_user_profiles;
create policy astra_user_profiles_update_self on public.astra_user_profiles for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid() and role_key='student_participant');
revoke all on public.astra_user_profiles from anon;
grant select,update on public.astra_user_profiles to authenticated;
drop policy if exists astra_app_state_select on public.astra_app_state;
create policy astra_app_state_select on public.astra_app_state for select to authenticated using(is_global or owner_id=auth.uid());
drop policy if exists astra_app_state_insert on public.astra_app_state;
create policy astra_app_state_insert on public.astra_app_state for insert to authenticated with check((is_global and owner_id is null and public.astra_can_manage_shared_state()) or (not is_global and owner_id=auth.uid()));
drop policy if exists astra_app_state_update on public.astra_app_state;
create policy astra_app_state_update on public.astra_app_state for update to authenticated using((is_global and public.astra_can_manage_shared_state()) or (not is_global and owner_id=auth.uid())) with check((is_global and owner_id is null and public.astra_can_manage_shared_state()) or (not is_global and owner_id=auth.uid()));
drop policy if exists astra_app_state_delete on public.astra_app_state;
create policy astra_app_state_delete on public.astra_app_state for delete to authenticated using((is_global and public.astra_can_manage_shared_state()) or (not is_global and owner_id=auth.uid()));
grant select,insert,update,delete on public.astra_app_state to authenticated;
do $$ begin if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='astra_app_state') then alter publication supabase_realtime add table public.astra_app_state; end if; end $$;
