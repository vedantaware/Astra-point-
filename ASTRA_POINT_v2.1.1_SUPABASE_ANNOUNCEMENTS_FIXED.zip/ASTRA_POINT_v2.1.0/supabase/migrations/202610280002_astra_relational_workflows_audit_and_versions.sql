-- ASTRA POINT v0.33.0: relational workflow hardening
alter table astra.teams add column if not exists version integer not null default 1;
alter table astra.budgets add column if not exists version integer not null default 1;
alter table astra.expenses add column if not exists version integer not null default 1;
alter table astra.meetings add column if not exists version integer not null default 1;
alter table astra.feedback_forms add column if not exists version integer not null default 1;
alter table astra.feedback_responses add column if not exists idempotency_key text;
alter table astra.feedback_responses add column if not exists client_submitted_at timestamptz;
alter table astra.team_members add column if not exists member_name text not null default '';
alter table astra.team_members add column if not exists member_label text not null default 'Member';
create unique index if not exists feedback_responses_idempotency_key_uidx on astra.feedback_responses (idempotency_key) where idempotency_key is not null;
create index if not exists notifications_recipient_created_idx on astra.notifications (recipient_id, created_at desc);
create index if not exists audit_logs_created_idx on astra.audit_logs (created_at desc);
create index if not exists feedback_responses_form_submitted_idx on astra.feedback_responses (form_id, submitted_at desc);
create or replace function astra.bump_version_and_audit()
returns trigger language plpgsql security definer set search_path = astra, pg_temp as $$
declare v_actor uuid := auth.uid(); v_entity_id text; v_action text; v_details jsonb;
begin
  if tg_op = 'UPDATE' then
    if to_jsonb(new) ? 'version' then new.version := coalesce(old.version, 0) + 1; end if;
    if to_jsonb(new) ? 'updated_at' then new.updated_at := now(); end if;
    v_entity_id := coalesce(to_jsonb(new)->>'id', to_jsonb(new)->>'user_id');
    v_action := lower(tg_table_name) || '.updated';
    v_details := jsonb_build_object('changed_fields',(select coalesce(jsonb_agg(fields.key), '[]'::jsonb) from jsonb_object_keys(to_jsonb(new)) as fields(key) where to_jsonb(new)->fields.key is distinct from to_jsonb(old)->fields.key and fields.key not in ('updated_at','version')));
  elsif tg_op = 'INSERT' then
    v_entity_id := coalesce(to_jsonb(new)->>'id', to_jsonb(new)->>'user_id'); v_action := lower(tg_table_name) || '.created';
    v_details := jsonb_build_object('record', jsonb_strip_nulls(jsonb_build_object('id',v_entity_id)));
  else
    v_entity_id := coalesce(to_jsonb(old)->>'id', to_jsonb(old)->>'user_id'); v_action := lower(tg_table_name) || '.deleted';
    v_details := jsonb_build_object('record', jsonb_strip_nulls(jsonb_build_object('id',v_entity_id)));
  end if;
  insert into astra.audit_logs(actor_id, action, entity_type, entity_id, details) values (v_actor, v_action, tg_table_name, v_entity_id, coalesce(v_details,'{}'::jsonb));
  if tg_op = 'DELETE' then return old; end if; return new;
end; $$;
revoke all on function astra.bump_version_and_audit() from public, anon, authenticated;
drop trigger if exists teams_version_audit on astra.teams;
create trigger teams_version_audit before insert or update or delete on astra.teams for each row execute function astra.bump_version_and_audit();
drop trigger if exists budgets_version_audit on astra.budgets;
create trigger budgets_version_audit before insert or update or delete on astra.budgets for each row execute function astra.bump_version_and_audit();
drop trigger if exists expenses_version_audit on astra.expenses;
create trigger expenses_version_audit before insert or update or delete on astra.expenses for each row execute function astra.bump_version_and_audit();
drop trigger if exists meetings_version_audit on astra.meetings;
create trigger meetings_version_audit before insert or update or delete on astra.meetings for each row execute function astra.bump_version_and_audit();
drop trigger if exists feedback_forms_version_audit on astra.feedback_forms;
create trigger feedback_forms_version_audit before insert or update or delete on astra.feedback_forms for each row execute function astra.bump_version_and_audit();
drop trigger if exists feedback_responses_audit on astra.feedback_responses;
create trigger feedback_responses_audit after insert or update or delete on astra.feedback_responses for each row execute function astra.bump_version_and_audit();
drop trigger if exists notifications_audit on astra.notifications;
create trigger notifications_audit after insert or update or delete on astra.notifications for each row execute function astra.bump_version_and_audit();
drop policy if exists feedback_responses_read_self_or_staff on astra.feedback_responses;
create policy feedback_responses_read_self_or_staff on astra.feedback_responses for select to authenticated using (respondent_id = (select auth.uid()) or astra.current_role() = any(array['platform_admin','admin','faculty_coordinator','council_president']));
drop policy if exists notifications_update_self on astra.notifications;
create policy notifications_update_self on astra.notifications for update to authenticated using (recipient_id = (select auth.uid())) with check (recipient_id = (select auth.uid()));
