-- ASTRA POINT public portal live data feeds.
-- Public visitors can read only active clubs, published/completed events,
-- explicitly public (audience = 'All') announcements, and published team members.
alter table public.campus_clubs enable row level security;
alter table public.campus_events enable row level security;
alter table public.campus_announcements enable row level security;

do $$ begin
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='campus_clubs' and policyname='Public can read active campus clubs') then
    create policy "Public can read active campus clubs" on public.campus_clubs for select to anon, authenticated using (status = 'active');
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='campus_events' and policyname='Public can read published campus events') then
    create policy "Public can read published campus events" on public.campus_events for select to anon, authenticated using (status in ('published','completed'));
  end if;
  if not exists (select 1 from pg_policies where schemaname='public' and tablename='campus_announcements' and policyname='Public can read published campus announcements') then
    create policy "Public can read published campus announcements" on public.campus_announcements for select to anon, authenticated using (status = 'published' and audience = 'All' and (expires_at is null or expires_at > now()));
  end if;
end $$;

grant select on public.campus_clubs, public.campus_events, public.campus_announcements, public.campus_sports_team_members to anon, authenticated;

do $$ begin alter publication supabase_realtime add table public.campus_clubs; exception when duplicate_object then null; end $$;
do $$ begin alter publication supabase_realtime add table public.campus_events; exception when duplicate_object then null; end $$;
do $$ begin alter publication supabase_realtime add table public.campus_announcements; exception when duplicate_object then null; end $$;
