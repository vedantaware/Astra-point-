drop policy if exists attendance_submit_self on astra.attendance;
create policy attendance_submit_self on astra.attendance for insert to authenticated with check (user_id = (select auth.uid()) and meeting_id is not null and event_id is null and status in ('Present','Absent','Late','Excused'));
drop policy if exists attendance_update_self on astra.attendance;
create policy attendance_update_self on astra.attendance for update to authenticated using (user_id = (select auth.uid()) and meeting_id is not null and event_id is null) with check (user_id = (select auth.uid()) and meeting_id is not null and event_id is null and status in ('Present','Absent','Late','Excused'));
