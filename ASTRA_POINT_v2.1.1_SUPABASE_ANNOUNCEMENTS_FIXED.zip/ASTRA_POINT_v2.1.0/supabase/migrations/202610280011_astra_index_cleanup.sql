drop index if exists astra.audit_logs_created_idx;
drop index if exists astra.feedback_responses_form_submitted_idx;
