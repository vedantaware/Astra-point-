-- ASTRA POINT role/data model draft. Review and test in a development Supabase project first.
-- This migration intentionally does not modify existing tables or create Auth users.
create extension if not exists pgcrypto;

create table if not exists public.astra_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  student_or_staff_code text,
  department text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.astra_roles (
  role_key text primary key,
  display_name text not null,
  description text not null default '',
  is_system_role boolean not null default false
);

create table if not exists public.astra_role_assignments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role_key text not null references public.astra_roles(role_key),
  scope_type text not null check (scope_type in ('platform','institution','council_term','committee','event','department')),
  scope_id uuid,
  valid_from timestamptz not null default now(),
  valid_until timestamptz,
  granted_by uuid references auth.users(id),
  revoked_at timestamptz,
  created_at timestamptz not null default now(),
  check (valid_until is null or valid_until > valid_from)
);

create table if not exists public.astra_council_terms (
  id uuid primary key default gen_random_uuid(),
  institution_name text not null,
  term_name text not null,
  starts_on date,
  ends_on date,
  source_document text,
  status text not null default 'draft' check (status in ('draft','active','archived')),
  created_at timestamptz not null default now(),
  check (ends_on is null or starts_on is null or ends_on >= starts_on)
);

create table if not exists public.astra_committees (
  id uuid primary key default gen_random_uuid(),
  council_term_id uuid references public.astra_council_terms(id) on delete restrict,
  committee_key text not null,
  name text not null,
  description text not null default '',
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique(council_term_id, committee_key)
);

create table if not exists public.astra_council_memberships (
  id uuid primary key default gen_random_uuid(),
  council_term_id uuid not null references public.astra_council_terms(id) on delete restrict,
  profile_user_id uuid references auth.users(id) on delete set null,
  source_name text not null,
  role_title text not null,
  class_name text,
  branch_or_department text,
  membership_type text not null check (membership_type in ('student','faculty')),
  source_serial integer,
  verification_status text not null default 'needs_review' check (verification_status in ('verified','needs_review','corrected')),
  source_notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.astra_committee_memberships (
  id uuid primary key default gen_random_uuid(),
  committee_id uuid not null references public.astra_committees(id) on delete cascade,
  profile_user_id uuid references auth.users(id) on delete set null,
  council_membership_id uuid references public.astra_council_memberships(id) on delete set null,
  role_title text not null default 'Committee Member',
  valid_from date,
  valid_until date,
  created_at timestamptz not null default now(),
  check (valid_until is null or valid_from is null or valid_until >= valid_from)
);

create table if not exists public.astra_events (
  id uuid primary key default gen_random_uuid(),
  event_code text unique,
  title text not null,
  description text not null default '',
  category text not null,
  organizer_user_id uuid not null references auth.users(id),
  committee_id uuid references public.astra_committees(id) on delete set null,
  starts_at timestamptz,
  ends_at timestamptz,
  venue text,
  capacity integer check (capacity is null or capacity >= 0),
  status text not null default 'draft' check (status in ('draft','submitted','stage1_approved','approved','returned_for_revision','rejected','published','registration_closed','completed','cancelled')),
  requires_stage2 boolean not null default true,
  submitted_at timestamptz,
  review_due_at timestamptz,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (ends_at is null or starts_at is null or ends_at >= starts_at)
);

create table if not exists public.astra_event_approvals (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.astra_events(id) on delete cascade,
  stage smallint not null check (stage in (1,2)),
  reviewer_user_id uuid not null references auth.users(id),
  decision text not null default 'pending' check (decision in ('pending','approved','returned_for_revision','rejected')),
  decision_reason text,
  decided_at timestamptz,
  due_at timestamptz,
  created_at timestamptz not null default now(),
  unique(event_id, stage),
  check ((decision = 'pending') or decided_at is not null),
  check ((decision not in ('returned_for_revision','rejected')) or length(trim(coalesce(decision_reason,''))) > 0)
);

create table if not exists public.astra_workflow_transitions (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.astra_events(id) on delete cascade,
  from_state text,
  to_state text not null,
  action_key text not null,
  actor_user_id uuid references auth.users(id),
  reason text,
  metadata jsonb not null default '{}'::jsonb,
  occurred_at timestamptz not null default now()
);

create table if not exists public.astra_audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_user_id uuid references auth.users(id),
  action_key text not null,
  resource_type text not null,
  resource_id uuid,
  previous_value jsonb,
  new_value jsonb,
  reason text,
  request_id text,
  occurred_at timestamptz not null default now()
);

create table if not exists public.astra_notifications (
  id uuid primary key default gen_random_uuid(),
  recipient_user_id uuid not null references auth.users(id) on delete cascade,
  event_id uuid references public.astra_events(id) on delete cascade,
  notification_type text not null,
  payload jsonb not null default '{}'::jsonb,
  scheduled_for timestamptz not null default now(),
  sent_at timestamptz,
  delivery_status text not null default 'queued' check (delivery_status in ('queued','sent','failed','cancelled')),
  attempts integer not null default 0,
  last_error text,
  created_at timestamptz not null default now()
);

create table if not exists public.astra_event_registrations (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.astra_events(id) on delete cascade,
  participant_user_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'registered' check (status in ('registered','waitlisted','cancelled','attended','no_show')),
  registered_at timestamptz not null default now(),
  unique(event_id, participant_user_id)
);

create index if not exists astra_role_assignments_user_idx on public.astra_role_assignments(user_id) where revoked_at is null;
create index if not exists astra_memberships_term_idx on public.astra_council_memberships(council_term_id);
create index if not exists astra_events_status_due_idx on public.astra_events(status, review_due_at);
create index if not exists astra_approvals_reviewer_idx on public.astra_event_approvals(reviewer_user_id, decision, due_at);
create index if not exists astra_notifications_queue_idx on public.astra_notifications(delivery_status, scheduled_for);

insert into public.astra_roles(role_key, display_name, description, is_system_role) values
 ('platform_admin','Platform Administrator','Platform configuration and role assignments',true),
 ('institution_approver','Institutional Approver','Institution-level approvals where policy requires',true),
 ('faculty_coordinator','Faculty Coordinator','Reviews assigned committee/department submissions',true),
 ('council_president','Council President','Council-term oversight and delegated operations',true),
 ('event_organizer','Event Organizer / Secretary','Creates and submits authorized event drafts',true),
 ('treasurer','Treasurer','Budget preparation and explicitly authorized review',true),
 ('committee_member','Committee Member / Volunteer','Assigned committee information and tasks',true),
 ('student_participant','Student Participant','Published events and own registrations',true),
 ('auditor_readonly','Auditor / Read-only Reviewer','Read-only access to explicitly granted records',true)
on conflict (role_key) do nothing;

-- Security intentionally fails closed: enable RLS but do not grant broad policies.
-- Add tested, scope-aware policies and trusted transition functions before client use.
alter table public.astra_profiles enable row level security;
alter table public.astra_roles enable row level security;
alter table public.astra_role_assignments enable row level security;
alter table public.astra_council_terms enable row level security;
alter table public.astra_committees enable row level security;
alter table public.astra_council_memberships enable row level security;
alter table public.astra_committee_memberships enable row level security;
alter table public.astra_events enable row level security;
alter table public.astra_event_approvals enable row level security;
alter table public.astra_workflow_transitions enable row level security;
alter table public.astra_audit_logs enable row level security;
alter table public.astra_notifications enable row level security;
alter table public.astra_event_registrations enable row level security;

-- IMPORTANT: With no policies, client roles have no table access through RLS.
-- This is a schema draft, not a deploy-ready migration. Test policies/functions in a
-- separate development Supabase project and perform role-by-role allow/deny tests.
