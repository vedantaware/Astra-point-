alter table astra.feedback_forms add column if not exists questions jsonb not null default '[]'::jsonb;
