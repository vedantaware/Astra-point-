drop policy if exists feedback_responses_submit on astra.feedback_responses;
create policy feedback_responses_submit on astra.feedback_responses for insert to authenticated with check (exists (select 1 from astra.feedback_forms f where f.id = form_id and f.status = 'Open' and ((f.anonymous = true and respondent_id is null) or (f.anonymous = false and respondent_id = (select auth.uid())))));
