drop policy if exists profiles_read_roster_managers on astra.profiles;
create policy profiles_read_roster_managers on astra.profiles for select to authenticated using (astra.current_role() = any(array['platform_admin','admin','council_president','faculty_coordinator','secretary']));
drop policy if exists audit_logs_no_client_update on astra.audit_logs;
create policy audit_logs_no_client_update on astra.audit_logs for update to authenticated using (false) with check (false);
drop policy if exists audit_logs_no_client_delete on astra.audit_logs;
create policy audit_logs_no_client_delete on astra.audit_logs for delete to authenticated using (false);
