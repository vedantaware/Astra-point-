-- ASTRA POINT: shared workspace state and relational task integration.
-- This migration targets the dedicated astra schema created for this project.

alter table astra.app_state alter column owner_id drop not null;
alter table astra.app_state add column if not exists scope_key text;
alter table astra.app_state add column if not exists is_global boolean not null default false;
alter table astra.app_state add column if not exists updated_by uuid references auth.users(id) on delete set null;
update astra.app_state set scope_key = owner_id::text || ':' || state_key where scope_key is null and owner_id is not null;
create unique index if not exists astra_app_state_scope_key_uidx on astra.app_state(scope_key);
create index if not exists astra_app_state_owner_key_idx on astra.app_state(owner_id,state_key);

alter table astra.tasks add column if not exists assignee_name text not null default '';

alter table astra.app_state enable row level security;
drop policy if exists app_state_owner_access on astra.app_state;
drop policy if exists app_state_read_scoped on astra.app_state;
drop policy if exists app_state_insert_scoped on astra.app_state;
drop policy if exists app_state_update_scoped on astra.app_state;
drop policy if exists app_state_delete_scoped on astra.app_state;
create policy app_state_read_scoped on astra.app_state for select to authenticated
using (owner_id = auth.uid() or is_global = true);
create policy app_state_insert_scoped on astra.app_state for insert to authenticated
with check (
 (is_global = false and owner_id = auth.uid() and scope_key = auth.uid()::text || ':' || state_key)
 or (is_global = true and owner_id is null and scope_key = 'global:' || state_key
  and astra.current_role() in ('platform_admin','admin','institution_approver','faculty_coordinator','council_president','event_organizer','treasurer','committee_member','club_lead','secretary'))
);
create policy app_state_update_scoped on astra.app_state for update to authenticated
using ((is_global = false and owner_id = auth.uid()) or (is_global = true and astra.current_role() in ('platform_admin','admin','institution_approver','faculty_coordinator','council_president','event_organizer','treasurer','committee_member','club_lead','secretary')))
with check (
 (is_global = false and owner_id = auth.uid() and scope_key = auth.uid()::text || ':' || state_key)
 or (is_global = true and owner_id is null and scope_key = 'global:' || state_key
  and astra.current_role() in ('platform_admin','admin','institution_approver','faculty_coordinator','council_president','event_organizer','treasurer','committee_member','club_lead','secretary'))
);
create policy app_state_delete_scoped on astra.app_state for delete to authenticated
using ((is_global = false and owner_id = auth.uid()) or (is_global = true and astra.current_role() in ('platform_admin','admin')));

grant select,insert,update,delete on astra.app_state to authenticated;
do $$ begin
 if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='astra' and tablename='app_state') then
  alter publication supabase_realtime add table astra.app_state;
 end if;
exception when undefined_object then null; end $$;
