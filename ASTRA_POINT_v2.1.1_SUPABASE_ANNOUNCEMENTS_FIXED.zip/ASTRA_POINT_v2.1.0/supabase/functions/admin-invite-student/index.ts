import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  const authHeader = req.headers.get("Authorization") ?? "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
  if (!token) return json({ error: "A signed-in platform-admin session is required." }, 401);

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const secretMapRaw = Deno.env.get("SUPABASE_SECRET_KEYS");
  const legacyServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  let secretKey = legacyServiceKey ?? "";
  if (!secretKey && secretMapRaw) {
    try {
      secretKey = JSON.parse(secretMapRaw).default ?? "";
    } catch {
      return json({ error: "Server secret configuration is invalid." }, 500);
    }
  }
  if (!supabaseUrl || !secretKey) return json({ error: "Server-side Supabase secret is not configured." }, 500);

  const admin = createClient(supabaseUrl, secretKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });

  const { data: authData, error: authError } = await admin.auth.getUser(token);
  if (authError || !authData.user) return json({ error: "Invalid or expired session." }, 401);

  const { data: callerProfile, error: profileError } = await admin
    .from("astra_user_profiles")
    .select("role_key, active")
    .eq("user_id", authData.user.id)
    .maybeSingle();
  if (profileError) return json({ error: "Unable to verify administrator role." }, 500);
  if (!callerProfile?.active || callerProfile.role_key !== "platform_admin") {
    return json({ error: "Only an active platform administrator can invite students." }, 403);
  }

  let body: Record<string, unknown>;
  try { body = await req.json(); }
  catch { return json({ error: "Request body must be valid JSON." }, 400); }

  const email = String(body.email ?? "").trim().toLowerCase();
  const displayName = String(body.display_name ?? "").trim();
  const username = String(body.username ?? "").trim().toLowerCase();
  const prn = String(body.prn ?? "").trim();
  const branch = String(body.branch ?? "").trim();
  const year = String(body.year_of_study ?? "").trim();

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json({ error: "A valid email is required." }, 400);
  if (displayName.length < 2 || displayName.length > 100) return json({ error: "Display name must be 2–100 characters." }, 400);
  if (!/^[a-z0-9._-]{3,32}$/.test(username)) return json({ error: "Username must be 3–32 characters (letters, numbers, dot, underscore or hyphen)." }, 400);
  if (!/^\d{3,20}$/.test(prn)) return json({ error: "PRN must contain 3–20 digits." }, 400);
  if (!branch || branch.length > 80 || !year || year.length > 40) return json({ error: "Branch and year/class are required." }, 400);

  const { data: inviteData, error: inviteError } = await admin.auth.admin.inviteUserByEmail(email, {
    data: { display_name: displayName, username },
  });
  if (inviteError) {
    const status = /already|registered|exists/i.test(inviteError.message) ? 409 : 400;
    return json({ error: inviteError.message }, status);
  }

  const invitedUser = inviteData.user;
  if (!invitedUser?.id) return json({ error: "Invite was accepted but no user ID was returned. Check Auth > Users." }, 502);

  const { error: upsertError } = await admin.from("astra_user_profiles").upsert({
    user_id: invitedUser.id,
    username,
    display_name: displayName,
    role_key: "student_participant",
    active: true,
    prn,
    branch,
    class_name: year,
    year_of_study: year,
    profile_visibility: "campus",
  }, { onConflict: "user_id" });

  if (upsertError) {
    return json({
      invited: true,
      user_id: invitedUser.id,
      warning: "Auth invite was created, but the student profile update failed. Contact an administrator before retrying.",
      profile_error: upsertError.message,
    }, 207);
  }

  await admin.from("admin_audit_logs").insert({
    actor_id: authData.user.id,
    action: "student_invited",
    entity_type: "auth_user",
    entity_id: invitedUser.id,
    details: { email, username, prn, branch, year_of_study: year },
  });

  return json({
    invited: true,
    user_id: invitedUser.id,
    email,
    role: "student_participant",
    profile: { display_name: displayName, username, prn, branch, year_of_study: year },
    message: "Student invitation sent. The student must accept the email invitation to set a password and sign in.",
  }, 201);
});
