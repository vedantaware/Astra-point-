# ASTRA POINT 2.0 — Student account provisioning

## Connected Supabase project

The provided `.env.example` targets project `noobyuyuwcjghyxszauq`. Copy it to `.env.local` before running the app. The publishable key is client-safe only when the database RLS policies remain enabled.

```bash
cp .env.example .env.local
npm install
npm run build
npm run dev
```

## Create a student account

1. Sign in using an existing active `platform_admin` Supabase account.
2. Open **Student Accounts** from the left navigation.
3. Enter the student's name, college email, username, PRN, branch and year/class.
4. Select **Create account & send invite**.
5. The student accepts the Supabase invitation email and sets their own password.

The browser calls the deployed `admin-invite-student` Edge Function with the current user session. The function verifies the caller's JWT and active platform-admin profile before inviting the user and writing their `student_participant` profile. A service/secret key is never included in this ZIP or frontend environment.

## Notes

- Student invitation is not performed automatically on app startup.
- Do not add a service-role or `sb_secret_` key to `.env.local`, Vercel client environment variables, or source control.
- The connected project is `https://noobyuyuwcjghyxszauq.supabase.co`. A different Supabase URL belongs to a different project and will not see the deployed invitation function.
- This ZIP contains the existing ASTRA POINT interface plus the account-invitation workflow; it does not claim every legacy dashboard screen has been migrated to the new campus tables.
