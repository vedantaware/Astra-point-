import type { CouncilEvent } from '../types'

// Initial ASTRA POINT campus event history supplied by the council.
// These records are local project data; they do not write to Supabase.
export const campusEvents: CouncilEvent[] = [
  { id: 'campus-sih-internal-hackathon-2026', title: 'SIH INTERNAL HACKATHON 2026', category: 'Hackathon', date: '2026-08-27', time: 'Time to be announced', venue: 'Siddhant College of Engineering', registrations: 0, capacity: 0, status: 'Completed', color: '#8b2942' },
  { id: 'campus-teachers-day-2026', title: "Teachers Day", category: 'Celebration', date: '2026-09-07', time: 'Time to be announced', venue: 'Siddhant College of Engineering', registrations: 0, capacity: 0, status: 'Completed', color: '#b77935' },
  { id: 'campus-avishkar-2026', title: 'Avishkar 2026', category: 'Innovation', date: '2026-09-15', time: 'Time to be announced', venue: 'Siddhant College of Engineering', registrations: 0, capacity: 0, status: 'Completed', color: '#3d7771' },
  { id: 'campus-first-year-induction-2026', title: 'Induction program of first year', category: 'Induction', date: '2026-09-16', time: 'Time to be announced', venue: 'Siddhant College of Engineering', registrations: 0, capacity: 0, status: 'Completed', color: '#5478a5' },
  { id: 'campus-garba-raas-2026', title: 'Garba Raas', category: 'Cultural', date: '2026-09-19', time: 'Time to be announced', venue: 'Siddhant College of Engineering', registrations: 0, capacity: 0, status: 'Completed', color: '#a04f75' },
  { id: 'campus-engineers-day-2026', title: "Engineer's Day", category: 'Celebration', date: '2026-09-22', time: 'Time to be announced', venue: 'Siddhant College of Engineering', registrations: 0, capacity: 0, status: 'Completed', color: '#6c6a9b' },
  { id: 'campus-spandan-2k27', title: 'Spandan 2K27', category: 'Major upcoming event', date: '2027-01-01', dateLabel: 'January–February 2027', time: 'Dates and schedule to be announced', venue: 'Siddhant College of Engineering', registrations: 0, capacity: 0, status: 'Published', color: '#8b2942' },
]
