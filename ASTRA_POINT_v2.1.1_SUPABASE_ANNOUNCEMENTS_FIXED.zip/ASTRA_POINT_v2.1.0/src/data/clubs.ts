export type ClubMember = { name: string; role: string }
export type StudentClub = { id: string; name: string; subtitle: string; logo: string; status: 'Active' | 'Launching soon'; team: ClubMember[]; description: string }

// Club names, logos, and leadership were supplied by the user. No membership counts are inferred.
export const studentClubs: StudentClub[] = [
  {
    id: 'aws-sbg', name: 'AWS SBG', subtitle: 'Student Builder', logo: '/clubs/aws-sbg.jpg', status: 'Active',
    description: 'Student Builder community focused on cloud and innovation.',
    team: [
      { name: 'Rupali Tagunde', role: 'Leader' },
      { name: 'Vedant Aware', role: 'Technical Lead' },
      { name: 'Dnyaneshwari Birajdar', role: 'Organising Lead' },
      { name: 'Dashrath Koli', role: 'Social Media Lead' },
      { name: 'Amey Shirsath', role: 'General Secretary' },
      { name: 'Shruti Kale', role: 'Event Lead' },
    ],
  },
  {
    id: 'forge-coding-club', name: 'FORGE CODING CLUB', subtitle: 'Build. Learn. Ship.', logo: '/clubs/forge-coding-club.jpg', status: 'Active',
    description: 'A student coding community for technical learning and building projects.',
    team: [
      { name: 'Kaustubh Bhabal', role: 'Leader' },
      { name: 'Swapnil Pawar', role: 'Co-Leader' },
      { name: 'Rukhsana', role: 'Co-Coordinator' },
      { name: 'Rupali Tagunde', role: 'Treasurer' },
      { name: 'Vedika Patil', role: 'Student Mentor' },
      { name: 'Madhav Semwal', role: 'Tech Lead' },
      { name: 'Pallavi Garje', role: 'Documentation Lead' },
      { name: 'Aryan Pentevar', role: 'Social Media Lead' },
      { name: 'Saqib Mukadam', role: 'Social Media Lead' },
      { name: 'Avdhesh Gupta', role: 'Social Media Lead' },
      { name: 'Prof. Richa Nigote', role: 'Training & Placement Officer' },
    ],
  },
  {
    id: 'naadsetu', name: 'NAADSETU', subtitle: 'Classic · Fusion · Acoustic', logo: '/clubs/naadsetu.jpg', status: 'Launching soon',
    description: 'A campus music initiative celebrating classic, fusion and acoustic sounds.',
    team: [],
  },
]
