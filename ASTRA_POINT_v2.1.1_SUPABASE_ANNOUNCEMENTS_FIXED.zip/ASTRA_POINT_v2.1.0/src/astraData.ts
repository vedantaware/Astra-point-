import { supabase, supabaseConfigured } from './lib_supabase'
import type { Approval, CouncilEvent } from './types'

const db = () => {
  if (!supabaseConfigured || !supabase) throw new Error('Supabase is not configured. Add the publishable key to .env.local.')
  return supabase.schema('astra')
}
const fmtDate = (value: string | null) => value ? new Date(value).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}) : 'To be scheduled'
const fmtTime = (value: string | null) => value ? new Date(value).toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'}) : 'Time to be announced'
const mapStatus = (s: string): CouncilEvent['status'] => s === 'Published' ? 'Published' : s === 'Completed' ? 'Completed' : s === 'Draft' ? 'Draft' : 'In review'
export function mapEvent(row: any): CouncilEvent {
  return { id: row.id, title: row.title, category: row.event_type || 'General', date: fmtDate(row.start_at), time: fmtTime(row.start_at), venue: row.location || 'Venue to be confirmed', registrations: 0, capacity: Number(row.capacity || 0), status: mapStatus(row.status), color: '#8b2942' }
}
export async function fetchEvents(): Promise<CouncilEvent[]> {
  if (!supabaseConfigured || !supabase) return []
  const {data,error}=await supabase.from('campus_events').select('*').in('status',['published','draft','completed']).order('starts_at',{ascending:true})
  if(error) throw error
  return (data||[]).map((row:any)=>({id:row.id,title:row.title,category:row.category||'Campus',date:fmtDate(row.starts_at),time:fmtTime(row.starts_at),venue:row.venue||'To be confirmed',registrations:0,capacity:Number(row.capacity||0),status:row.status==='published'?'Published':row.status==='completed'?'Completed':'Draft',color:'#8b2942'}))
}
export async function insertEvent(input:{title:string;category:string;date:string;venue:string;capacity:number;createdBy:string}) {
  if (!supabaseConfigured || !supabase) throw new Error('Supabase is not configured.')
  const startsAt = input.date ? new Date(`${input.date}T12:00:00`).toISOString() : new Date(Date.now()+7*86400000).toISOString()
  const {data,error}=await supabase.from('campus_events').insert({title:input.title,category:input.category,starts_at:startsAt,venue:input.venue,capacity:input.capacity,status:'draft',created_by:input.createdBy}).select('*').single()
  if(error) throw error
  return {id:data.id,title:data.title,category:data.category||'Campus',date:fmtDate(data.starts_at),time:fmtTime(data.starts_at),venue:data.venue||'To be confirmed',registrations:0,capacity:Number(data.capacity||0),status:'Draft',color:'#8b2942'} as CouncilEvent
}
export async function submitApproval(input:{title:string;description:string;type:string;requesterId:string}) {
  const {data,error}=await db().from('approvals').insert({title:input.title,description:input.description,approval_type:input.type,requested_by:input.requesterId,status:'Pending'}).select('*').single()
  if(error) throw error
  return {id:data.id,title:data.title,type:data.approval_type||'General',by:input.requesterId,date:fmtDate(data.created_at)} as Approval
}
export async function fetchApprovals(): Promise<Approval[]> {
  // The active campus schema does not yet contain a generic approvals queue.
  return []
}
export async function reviewApproval(id:string|number, decision:'Approved'|'Returned', actorId:string, actorName:string) {
  const status = decision === 'Approved' ? 'Approved' : 'Changes Requested'
  const {data,error}=await db().from('approvals').update({status,reviewed_by:actorId,reviewed_at:new Date().toISOString(),review_notes:decision==='Returned'?'Changes requested by reviewer.':`Approved by ${actorName}.`}).eq('id',String(id)).select('id').maybeSingle()
  if(error) throw error
  if(!data) throw new Error('No record was updated. You may not have permission to review this request, or it is no longer pending.')
  const {error:historyError}=await db().from('approval_history').insert({approval_id:String(id),action:decision==='Approved'?'Approved':'Changes Requested',notes:decision==='Approved'?`Approved by ${actorName}.`:'Changes requested by reviewer.',actor_id:actorId})
  if(historyError) console.error('[ASTRA] Approval updated but history insert failed:',historyError.message)
}
export async function fetchAnnouncements() {
  const {data,error}=await db().from('announcements').select('*').order('created_at',{ascending:false})
  if(error) throw error
  return data||[]
}
export async function saveAnnouncement(input:{title:string;content:string;audience:string;teamId:string|null;published:boolean;createdBy:string}) {
  const {data,error}=await db().from('announcements').insert({title:input.title,content:input.content,audience:input.audience,team_id:input.teamId,is_published:input.published,published_at:input.published?new Date().toISOString():null,created_by:input.createdBy}).select('*').single()
  if(error) throw error
  return data
}
export async function setAnnouncementPublished(id:string|number,published:boolean) {
  const {error}=await db().from('announcements').update({is_published:published,published_at:published?new Date().toISOString():null}).eq('id',String(id))
  if(error) throw error
}
export async function deleteAnnouncement(id:string|number) {
  const {error}=await db().from('announcements').delete().eq('id',String(id))
  if(error) throw error
}


export interface CloudTask { id: string | number; title: string; owner: string; due: string; priority: 'High'|'Medium'|'Low'; done: boolean }
export async function fetchTasks(): Promise<CloudTask[]> {
  // Task-board persistence is not part of the active campus schema yet.
  return []
}
export async function insertTask(input:{title:string;owner:string;due:string;priority:'High'|'Medium'|'Low';createdBy:string}) {
  const {data,error}=await db().from('tasks').insert({title:input.title,assignee_name:input.owner,due_at:input.due?new Date(`${input.due}T23:59:00`).toISOString():null,priority:input.priority,status:'Todo',assigned_by:input.createdBy}).select('id,title,assignee_name,due_at,priority,status').single()
  if(error) throw error
  return {id:data.id,title:data.title,owner:data.assignee_name||'Unassigned',due:data.due_at?new Date(data.due_at).toISOString().slice(0,10):'No due date',priority:data.priority as CloudTask['priority'],done:data.status==='Done'}
}
export async function updateTaskCompletion(id:string|number,done:boolean) {
  const {data,error}=await db().from('tasks').update({status:done?'Done':'Todo'}).eq('id',String(id)).select('id').maybeSingle()
  if(error) throw error
  if(!data) throw new Error('Task was not updated. Check your permissions and refresh the list.')
}

// Relational workflows: all writes use the authenticated user's JWT and are constrained by RLS.
export async function fetchMeetings() {
  const { data, error } = await db().from('meetings').select('*').order('starts_at', { ascending: true, nullsFirst: false })
  if (error) throw error
  return data || []
}
export async function createMeeting(input:{title:string;startsAt:string;location:string;agenda:string;createdBy:string}) {
  const {data,error}=await db().from('meetings').insert({title:input.title,starts_at:input.startsAt,location:input.location,agenda:input.agenda,minutes:'',status:'Scheduled',created_by:input.createdBy}).select('*').single()
  if(error) throw error
  return data
}
export async function updateMeeting(id:string, patch:{minutes?:string;status?:string}, expectedVersion?:number) {
  let q=db().from('meetings').update({...patch,updated_at:new Date().toISOString()}).eq('id',id)
  if(expectedVersion!==undefined) q=q.eq('version',expectedVersion)
  const {data,error}=await q.select('*').maybeSingle()
  if(error) throw error
  if(!data) throw new Error('Conflict: this meeting changed or you do not have permission. Refresh and retry.')
  return data
}
export async function fetchTeams() {
  const [{data:teams,error:teamError},{data:members,error:memberError}]=await Promise.all([
    db().from('teams').select('*').order('created_at',{ascending:false}),
    db().from('team_members').select('team_id,user_id,member_role,member_name,member_label')
  ])
  if(teamError) throw teamError
  if(memberError) throw memberError
  return (teams||[]).map((team:any)=>({...team,team_members:(members||[]).filter((m:any)=>m.team_id===team.id)}))
}
export async function createTeam(input:{name:string;category:string;description:string;createdBy:string}) {
  const {data,error}=await db().from('teams').insert({name:input.name,category:input.category,description:input.description,created_by:input.createdBy}).select('*').single()
  if(error) throw error
  return data
}
export async function updateTeam(id:string, patch:{name?:string;category?:string;description?:string}, expectedVersion?:number) {
  let q=db().from('teams').update({...patch,updated_at:new Date().toISOString()}).eq('id',id)
  if(expectedVersion!==undefined) q=q.eq('version',expectedVersion)
  const {data,error}=await q.select('*').maybeSingle()
  if(error) throw error
  if(!data) throw new Error('Conflict: this team changed or you do not have permission. Refresh before editing.')
  return data
}
export async function deleteTeam(id:string) {
  const {error}=await db().from('teams').delete().eq('id',id)
  if(error) throw error
}
export async function fetchFeedbackForms() {
  const {data,error}=await db().from('feedback_forms').select('*').order('created_at',{ascending:false})
  if(error) throw error
  return data || []
}
export async function createFeedbackForm(input:{title:string;audience:string;questions:string[];anonymous:boolean;createdBy:string}) {
  const {data,error}=await db().from('feedback_forms').insert({title:input.title,audience:input.audience,questions:input.questions,question_count:input.questions.length,anonymous:input.anonymous,status:'Open',created_by:input.createdBy}).select('*').single()
  if(error) throw error
  return data
}
export async function setFeedbackFormStatus(id:string,status:'Open'|'Closed',expectedVersion?:number) {
  let q=db().from('feedback_forms').update({status,updated_at:new Date().toISOString()}).eq('id',id)
  if(expectedVersion!==undefined) q=q.eq('version',expectedVersion)
  const {data,error}=await q.select('*').maybeSingle()
  if(error) throw error
  if(!data) throw new Error('Conflict: the form changed or your role cannot update it. Refresh and retry.')
  return data
}
export async function submitFeedbackResponse(input:{formId:string;answers:Record<string,unknown>;respondentId:string|null;idempotencyKey:string}) {
  const {data,error}=await db().from('feedback_responses').insert({form_id:input.formId,answers:input.answers,respondent_id:input.respondentId,idempotency_key:input.idempotencyKey,client_submitted_at:new Date().toISOString()}).select('*').single()
  if(error) {
    if(error.code==='23505') return {duplicate:true}
    throw error
  }
  return {duplicate:false,data}
}
export async function countFeedbackResponses(formIds:string[]) {
  if(!formIds.length) return {} as Record<string,number>
  const {data,error}=await db().from('feedback_responses').select('form_id').in('form_id',formIds)
  if(error) throw error
  return (data||[]).reduce((acc:any,row:any)=>{acc[row.form_id]=(acc[row.form_id]||0)+1;return acc},{} as Record<string,number>)
}
export async function fetchNotifications(userId:string) {
  if (!supabaseConfigured || !supabase) return []
  const {data,error}=await supabase.from('campus_notifications').select('*').or(`user_id.is.null,user_id.eq.${userId}`).order('created_at',{ascending:false}).limit(50)
  if(error) throw error
  const ids=(data||[]).map((n:any)=>n.id)
  const reads=ids.length?await supabase.from('notification_reads').select('notification_id,read_at').eq('user_id',userId).in('notification_id',ids):{data:[],error:null}
  if(reads.error) throw reads.error
  const readMap=new Map((reads.data||[]).map((r:any)=>[r.notification_id,r.read_at]))
  return (data||[]).map((n:any)=>({...n,recipient_id:n.user_id,read_at:readMap.get(n.id)||null}))
}
export async function createNotification(input:{recipientId:string;title:string;body:string;category:string}) {
  if (!supabaseConfigured || !supabase) throw new Error('Supabase is not configured.')
  const {data,error}=await supabase.from('campus_notifications').insert({user_id:input.recipientId,title:input.title,body:input.body,category:input.category}).select('*').single()
  if(error) throw error
  return data
}
export async function markNotificationRead(id:string) {
  if (!supabaseConfigured || !supabase) throw new Error('Supabase is not configured.')
  const {data:{user},error:userError}=await supabase.auth.getUser()
  if(userError||!user) throw new Error('Sign in again to update notification status.')
  const {error}=await supabase.from('notification_reads').upsert({notification_id:id,user_id:user.id},{onConflict:'notification_id,user_id',ignoreDuplicates:true})
  if(error) throw error
}
export async function fetchAuditLogs() {
  if (!supabaseConfigured || !supabase) return []
  const {data,error}=await supabase.from('admin_audit_logs').select('id,actor_id,action,entity_type,entity_id,details,created_at').order('created_at',{ascending:false}).limit(500)
  if(error) throw error
  return data || []
}

export async function fetchBudgets() {
  const {data,error}=await db().from('budgets').select('*,teams(name),expenses(id,title,amount,vendor,receipt_reference,status,submitted_by,reviewed_by,notes,created_at,version)').order('created_at',{ascending:false})
  if(error) throw error
  return data || []
}
export async function createBudget(input:{name:string;teamId:string|null;allocated:number;fiscalPeriod:string;createdBy:string}) {
  const {data,error}=await db().from('budgets').insert({name:input.name,team_id:input.teamId,allocated:input.allocated,fiscal_period:input.fiscalPeriod,created_by:input.createdBy}).select('*').single()
  if(error) throw error
  return data
}
export async function updateBudget(id:string,patch:{allocated?:number;name?:string},expectedVersion?:number) {
  let q=db().from('budgets').update({...patch,updated_at:new Date().toISOString()}).eq('id',id)
  if(expectedVersion!==undefined) q=q.eq('version',expectedVersion)
  const {data,error}=await q.select('*').maybeSingle()
  if(error) throw error
  if(!data) throw new Error('Conflict: budget changed or your role cannot update it. Refresh and retry.')
  return data
}
export async function createExpense(input:{budgetId:string|null;title:string;amount:number;vendor:string;receiptReference:string;submittedBy:string;notes:string}) {
  const {data,error}=await db().from('expenses').insert({budget_id:input.budgetId,title:input.title,amount:input.amount,vendor:input.vendor||'Not specified',receipt_reference:input.receiptReference||'Not provided',status:'Pending',submitted_by:input.submittedBy,notes:input.notes||''}).select('*').single()
  if(error) throw error
  return data
}
export async function reviewExpense(id:string,decision:'Approved'|'Rejected',reviewedBy:string,expectedVersion?:number) {
  let q=db().from('expenses').update({status:decision,reviewed_by:reviewedBy,updated_at:new Date().toISOString()}).eq('id',id).neq('submitted_by',reviewedBy)
  if(expectedVersion!==undefined) q=q.eq('version',expectedVersion)
  const {data,error}=await q.select('*').maybeSingle()
  if(error) throw error
  if(!data) throw new Error('Conflict or permission denied: only an authorized reviewer other than the submitter may review this expense.')
  return data
}
export async function fetchProfiles() {
  if (!supabaseConfigured || !supabase) return []
  const {data,error}=await supabase.from('astra_user_profiles').select('user_id,display_name,role_key,active').eq('active',true).order('display_name')
  if(error) throw error
  return (data||[]).map((p:any)=>({...p,role:p.role_key}))
}
export async function addTeamMember(input:{teamId:string;userId:string;role:string;memberName:string;memberLabel:string}) {
  const {data,error}=await db().from('team_members').insert({team_id:input.teamId,user_id:input.userId,member_role:input.role,member_name:input.memberName,member_label:input.memberLabel}).select('*').single()
  if(error) throw error
  return data
}
export async function removeTeamMember(teamId:string,userId:string) {
  const {error}=await db().from('team_members').delete().eq('team_id',teamId).eq('user_id',userId)
  if(error) throw error
}

export async function fetchMyMeetingAttendance(userId:string) {
  const {data,error}=await db().from('attendance').select('id,meeting_id,status,created_at').eq('user_id',userId).not('meeting_id','is',null)
  if(error) throw error
  return data || []
}
export async function markMyMeetingAttendance(meetingId:string,userId:string,status:'Present'|'Absent'|'Late'|'Excused'='Present') {
  const {data:existing,error:lookupError}=await db().from('attendance').select('id').eq('meeting_id',meetingId).eq('user_id',userId).limit(1).maybeSingle()
  if(lookupError) throw lookupError
  if(existing){
    const {data,error}=await db().from('attendance').update({status,recorded_by:null}).eq('id',existing.id).select('id').maybeSingle()
    if(error) throw error
    if(!data) throw new Error('Attendance was not updated. Check your permissions.')
    return
  }
  const {error}=await db().from('attendance').insert({meeting_id:meetingId,user_id:userId,status,recorded_by:null})
  if(error) throw error
}
