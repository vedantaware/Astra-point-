export type Page = 'Overview' | 'Calendar' | 'Events' | 'Council' | 'Committees' | 'Tasks' | 'Approvals' | 'Applications' | 'Budget' | 'Media' | 'Certificates' | 'Feedback' | 'Reports' | 'Roles' | 'Meetings' | 'Notices' | 'Inventory' | 'Partnerships' | 'Elections' | 'Audit' | 'Letters' | 'Rankings' | 'Hall of Fame' | 'Clubs' | 'Teams' | 'Website CMS' | 'My Submissions' | 'My Profile' | 'My Projects' | 'Help Desk' | 'Academic Hub' | 'My Activity' | 'Student Accounts'
export type EventStatus = 'Published' | 'In review' | 'Draft' | 'Completed'
export interface CouncilEvent {
  id: string
  title: string
  category: string
  date: string
  dateLabel?: string
  time: string
  venue: string
  registrations: number
  capacity: number
  status: EventStatus
  color: string
}
export interface TaskItem { id: string | number; title: string; owner: string; due: string; priority: 'High'|'Medium'|'Low'; done: boolean }
export interface Approval { id: string | number; title: string; type: string; by: string; date: string; amount?: string }
