import { useEffect, useState, type FormEvent } from 'react'
import { ArrowRight, LogOut, ShieldCheck } from 'lucide-react'
import Workspace from './App'
import { LogoMark } from './AuthVisual'
import PublicPortal from './PublicPortal'
import { authenticate, loadLocalSession, saveLocalSession, toProfile } from './localAuth'
import { supabase, supabaseConfigured } from './lib_supabase'
import './auth.css'

type Profile = { user_id:string; username:string; display_name:string; role_key:string; active:boolean; scope_type:string|null; scope_id:string|null }
const usernameOK=(s:string)=>/^[a-z0-9][a-z0-9._-]{2,31}$/.test(s)

export default function AuthRoot(){
 const [profile,setProfile]=useState<Profile|null>(null),[loading,setLoading]=useState(true)
 const [username,setUsername]=useState(''),[password,setPassword]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState('')
 const [showLogin,setShowLogin]=useState(false)
 const [backendNotice,setBackendNotice]=useState('')
 useEffect(()=>{
  // One-time cleanup of prototype/demo operational records only. Keep auth sessions,
  // provisioned accounts, the council roster, theme preferences, and all Supabase data.
  try{
   const marker='astra-point-demo-cleanup-v1'
   if(localStorage.getItem(marker)!=='done'){
    const prefixes=['astra-point-demo-','astra-demo-','astra-point-scms-budget-']
    const remove:string[]=[]
    for(let i=0;i<localStorage.length;i++){const key=localStorage.key(i);if(key&&prefixes.some(prefix=>key.startsWith(prefix)))remove.push(key)}
    remove.forEach(key=>localStorage.removeItem(key))
    localStorage.setItem(marker,'done')
   }
  }catch{/* Storage may be unavailable; app should still load. */}
  if(!supabaseConfigured || !supabase){const local=loadLocalSession() as Profile|null;if(local?.role_key==='platform_admin'&&local.active)setProfile(local);else if(local){saveLocalSession(null)}setLoading(false);return}
  let alive=true
  const hydrate=async(sessionUser:{id:string;email?:string}|null)=>{
   if(!sessionUser){if(alive)setProfile(null);return}
   const {data,error}=await supabase!.from('astra_user_profiles').select('user_id,username,display_name,role_key,active').eq('user_id',sessionUser.id).maybeSingle()
   if(error) console.warn('[ASTRA] Profile load:',error.message)
   const p:Profile={user_id:sessionUser.id,username:sessionUser.email?.split('@')[0]||'',display_name:data?.display_name||sessionUser.email||'ASTRA user',role_key:data?.role_key||'student_participant',active:data?.active??true,scope_type:null,scope_id:null}
   if(!['platform_admin','student_participant','club_lead','committee_member','council_president','event_organizer','faculty_coordinator','institution_approver','treasurer','auditor_readonly'].includes(p.role_key)||!p.active){
    if(alive){setProfile(null);setShowLogin(true);setError('This portal is managed by the Super Admin. Your account is inactive or does not have an ASTRA POINT access role.')}
    void supabase!.auth.signOut()
    return
   }
   if(alive){setProfile(p)}
  }
  void supabase.auth.getSession().then(({data})=>hydrate(data.session?.user||null)).finally(()=>{if(alive)setLoading(false)})
  const {data:{subscription}}=supabase.auth.onAuthStateChange((_event,session)=>{void hydrate(session?.user||null)})
  return()=>{alive=false;subscription.unsubscribe()}
 },[])
 const signIn=async(e:FormEvent)=>{e.preventDefault();setError('');setBackendNotice('');setBusy(true);try{
  if(supabaseConfigured&&supabase){
   const email=username.trim().toLowerCase();if(!email.includes('@'))throw new Error('Supabase sign-in requires the email address used during registration.');const {error}=await supabase.auth.signInWithPassword({email,password});if(error)throw error;setPassword('');return
  }
  const account=await authenticate(username,password);if(!account)throw new Error('Invalid username/email or password. Check the credentials file included in this ZIP.');const p=toProfile(account) as Profile;if(p.role_key!=='platform_admin'||!p.active)throw new Error('Student and staff sign-in requires the configured Supabase backend. Local offline mode is restricted to the Super Admin.');setProfile(p);saveLocalSession(account.id);setPassword('')
 }catch(e){setError(e instanceof Error?e.message:'Sign in failed.')}finally{setBusy(false)}}
 const signOut=()=>{if(supabaseConfigured&&supabase){void supabase.auth.signOut()}else saveLocalSession(null);setProfile(null)}
 if(loading)return <div className="auth-loading"><div className="auth-logo-mark"><img src="/astra-logo.png" alt="ASTRA logo" /></div><span>Loading ASTRA POINT secure workspace…</span></div>
 if(!profile)return showLogin ? <div className="auth-screen"><div className="auth-split"><section className="auth-showcase"><div className="auth-brand"><LogoMark/><div><strong>ASTRA <span>POINT</span></strong><small>COLLEGE ANNOUNCEMENTS & UPDATES</small></div><div className="council-brand" aria-label="Siddhant College Student Council"><img src="/brand/siddhant-council-logo.png" alt="Siddhant College of Engineering Student Council logo"/><span>SIDHHANT COLLEGE<br/>STUDENT COUNCIL</span></div></div><div className="showcase-copy"><span className="showcase-kicker">COLLEGE UPDATES · ONE OFFICIAL SOURCE</span><h2>Stay informed.<br/><em>Stay connected.</em></h2><p>Official announcements, campus events and important college updates — all in one place.</p><div className="showcase-visual"><div className="showcase-orbit orbit-x"/><div className="showcase-orbit orbit-y"/><div className="showcase-core">A</div><span className="showcase-star star-one">✦</span><span className="showcase-star star-two">✧</span></div></div><div className="showcase-footer"><span>BUILT FOR STUDENT-LED IMPACT</span><span>ASTRA POINT</span></div></section><section className="auth-card"><div className="auth-intro"><span className="panel-kicker">SECURE CAMPUS ACCESS</span><h1>Welcome to ASTRA POINT.</h1><p>{supabaseConfigured?'Sign in with your authorised student or staff account. Your workspace is determined by your verified role.':'Local offline mode is restricted to the Super Admin. Configure Supabase Auth to enable student and staff accounts.'}</p></div><form className="auth-form" onSubmit={signIn}><label className="field">{supabaseConfigured?'Email address':'Username or email'}<input autoComplete="username" autoCapitalize="none" value={username} onChange={e=>setUsername(e.target.value)} placeholder={supabaseConfigured?'you@example.com':'your.username'} type={supabaseConfigured?'email':'text'} required maxLength={254}/></label><label className="field">Password<input type="password" autoComplete="current-password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Enter your password" required/></label>{error&&<div className="auth-error" role="alert">{error}</div>}<button className="button button-primary auth-submit" disabled={busy||!username.trim()||!password}>{busy?'Signing in…':supabaseConfigured?'Sign in to ASTRA POINT':'Sign in as Super Admin'} <ArrowRight size={16}/></button></form>{backendNotice&&<div className="created-notice" role="status">{backendNotice}</div>}{supabaseConfigured?<div className="auth-foot"><ShieldCheck size={15}/><span>Protected with Supabase Auth · Role-based campus access.</span></div>:<div className="auth-foot"><ShieldCheck size={15}/><span>Local administrator mode · Configure Supabase Auth for secure deployment.</span></div>}<p className="auth-copyright">ASTRA POINT · College information portal</p><button type="button" className="portal-back-link" onClick={()=>setShowLogin(false)}>← Back to college home</button></section></div></div> : <PublicPortal onLogin={()=>setShowLogin(true)}/>
 return <><div className="auth-session-actions"><span><ShieldCheck size={14}/> {profile.display_name} · {profile.role_key.replaceAll('_',' ').toUpperCase()}</span><div><button onClick={signOut}><LogOut size={14}/> Sign out</button></div></div><Workspace profile={profile} onSignOut={signOut}/></>
}
