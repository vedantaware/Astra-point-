import { useState, type FormEvent } from 'react'
import { ArrowUpRight, CheckCircle2, MailPlus, ShieldCheck, UserPlus } from 'lucide-react'
import { supabase, supabaseConfigured } from './lib_supabase'

type InviteResult = { invited?: boolean; email?: string; role?: string; message?: string; warning?: string; error?: string }

export default function StudentAccounts(){
  const [email,setEmail]=useState('vedantaware11@gmail.com')
  const [displayName,setDisplayName]=useState('Vedant Aware')
  const [username,setUsername]=useState('vedantaware11')
  const [prn,setPrn]=useState('12345')
  const [branch,setBranch]=useState('AIML')
  const [year,setYear]=useState('SE')
  const [busy,setBusy]=useState(false)
  const [error,setError]=useState('')
  const [result,setResult]=useState<InviteResult|null>(null)

  const submit=async(e:FormEvent)=>{
    e.preventDefault();setError('');setResult(null)
    if(!supabaseConfigured||!supabase){setError('Supabase is not configured. Check your .env.local file.');return}
    setBusy(true)
    try{
      const {data,error:invokeError}=await supabase.functions.invoke('admin-invite-student',{body:{email:email.trim(),display_name:displayName.trim(),username:username.trim().toLowerCase(),prn:prn.trim(),branch:branch.trim(),year_of_study:year.trim()}})
      if(invokeError)throw new Error(invokeError.message||'Could not contact the student invitation service.')
      if(data?.error)throw new Error(data.error)
      setResult(data as InviteResult)
    }catch(err){setError(err instanceof Error?err.message:'Student invitation failed.')}finally{setBusy(false)}
  }

  return <div className="module-stack student-accounts">
    <section className="panel student-account-intro"><div className="student-account-icon"><UserPlus size={22}/></div><div><span className="panel-kicker">PLATFORM ADMINISTRATOR</span><h2>Create a student account</h2><p>Send a secure Supabase email invitation and create the student's ASTRA POINT profile. Students set their own password through the invitation email.</p></div></section>
    {!supabaseConfigured&&<div className="auth-error">Supabase is not configured. Add the project URL and publishable key to .env.local.</div>}
    <form className="panel composer-panel" onSubmit={submit}>
      <div className="table-heading"><div><h3>Student identity</h3><p>Use the student's official college details. PRN is unique.</p></div><span className="demo-pill"><i/> SECURE INVITE</span></div>
      <div className="form-grid">
        <label className="field">Full name<input required maxLength={100} value={displayName} onChange={e=>setDisplayName(e.target.value)} placeholder="Student full name"/></label>
        <label className="field">College email<input required type="email" maxLength={254} value={email} onChange={e=>setEmail(e.target.value)} placeholder="student@college.edu"/></label>
        <label className="field">Username<input required minLength={3} maxLength={32} value={username} onChange={e=>setUsername(e.target.value)} placeholder="student.username"/></label>
        <label className="field">PRN<input required inputMode="numeric" pattern="[0-9]{3,20}" maxLength={20} value={prn} onChange={e=>setPrn(e.target.value.replace(/\D/g,''))} placeholder="College PRN"/></label>
        <label className="field">Branch / Department<input required maxLength={80} value={branch} onChange={e=>setBranch(e.target.value)} placeholder="AIML"/></label>
        <label className="field">Year / Class<input required maxLength={40} value={year} onChange={e=>setYear(e.target.value)} placeholder="SE"/></label>
      </div>
      {error&&<div className="auth-error" role="alert">{error}</div>}
      {result?.invited&&<div className="student-invite-success"><CheckCircle2 size={19}/><div><strong>Invitation created for {result.email}</strong><span>{result.message||'The student must accept the invitation email before signing in.'}</span>{result.warning&&<span>{result.warning}</span>}</div></div>}
      <div className="action-row"><button className="button button-primary" type="submit" disabled={busy||!supabaseConfigured}>{busy?'Creating invitation…':'Create account & send invite'} <MailPlus size={15}/></button><span>The function verifies your platform-admin session. No password is generated or displayed here.</span></div>
    </form>
    <section className="panel student-account-security"><ShieldCheck size={18}/><div><strong>Security controls</strong><p>Only an active platform administrator can use this endpoint. The server validates the session, assigns <code>student_participant</code>, enforces PRN uniqueness and writes an audit record. Never place a Supabase secret key in this frontend.</p></div><a href="https://supabase.com/dashboard/project/noobyuyuwcjghyxszauq/auth/users" target="_blank" rel="noreferrer">Auth users <ArrowUpRight size={13}/></a></section>
  </div>
}
