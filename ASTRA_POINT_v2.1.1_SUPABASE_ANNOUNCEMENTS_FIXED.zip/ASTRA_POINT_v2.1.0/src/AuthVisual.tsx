export function LogoMark(){return <span className="auth-logo-mark"><img src="/astra-logo.png" alt="ASTRA logo" /></span>}
