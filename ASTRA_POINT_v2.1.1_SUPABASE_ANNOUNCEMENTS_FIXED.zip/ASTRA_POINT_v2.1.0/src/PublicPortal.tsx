import { useEffect, useMemo, useState, type ReactNode } from 'react'
import {
  ArrowRight, Bell, CalendarDays, ChevronRight, Search, Users, Megaphone,
  Trophy, Menu, X, ShieldCheck, BookOpen, ClipboardCheck, MessageSquareText,
  Award, CircleUserRound, Sparkles, GraduationCap, CalendarCheck2, Image as ImageIcon,
  Info, Mail, Compass, CalendarClock
} from 'lucide-react'
import { councilPeople } from './data/council'
import { supabase } from './lib_supabase'
import { studentClubs, type StudentClub } from './data/clubs'
import { campusEvents } from './data/events'
import type { CouncilEvent } from './types'
import './public-portal.css'

type PortalTab = 'all' | 'notices' | 'events' | 'council' | 'services' | 'clubs' | 'teams' | 'hall-of-fame' | 'gallery' | 'about' | 'contact'
type PublicNotice = { id:number|string; title:string; body:string; status:string; publicPortal?:boolean; audience?:string; updated?:string; expiry?:string }
type WebsiteContent = { headline:string; subheadline:string; banner:string; about:string }
const WEBSITE_CMS_KEY='astra-point-website-cms-v1'
const DEFAULT_WEBSITE_CONTENT:WebsiteContent={headline:'Your campus. Your council. Your voice.',subheadline:'Discover the people, events and ideas shaping campus life.',banner:'Welcome to the student council portal.',about:'A central place for campus announcements, events, clubs and student achievements.'}
function getWebsiteContent():WebsiteContent{return readLocal<WebsiteContent>(WEBSITE_CMS_KEY,DEFAULT_WEBSITE_CONTENT)}
const EVENTS_KEY='astra-point-demo-events'
const NOTICES_KEY='astra-point-demo-announcements'
const TEAMS_KEY='astra-point-campus-teams-v1'
const ACHIEVEMENTS_KEY='astra-point-achievement-records-v1'
type PublicTeamMember={id:string;name:string;role:string}
type PublicTeam={id:string;name:string;category:string;coach:string;season:string;members:PublicTeamMember[]}
type PublicAchievement={id:string;title:string;person:string;category:string;competition:string;result:string;story:string;submittedBy:string;date:string;status:'In review'|'Published'|'Returned';featured:boolean}
function getPublicTeams(){return readLocal<PublicTeam[]>(TEAMS_KEY,[])}
function getPublicAchievements(){return readLocal<PublicAchievement[]>(ACHIEVEMENTS_KEY,[]).filter(a=>a.status==='Published')}

function readLocal<T>(key:string,fallback:T):T{try{const raw=window.localStorage.getItem(key);if(!raw)return fallback;const parsed=JSON.parse(raw);return parsed as T}catch{return fallback}}
function getPublicEvents(){const saved=readLocal<CouncilEvent[]>(EVENTS_KEY,campusEvents);const source=saved.length?saved:campusEvents;return source.filter(e=>e.status==='Published'||e.status==='Completed')}
function getPublicNotices(){return readLocal<PublicNotice[]>(NOTICES_KEY,[]).filter(n=>n.status==='Published'&&n.publicPortal===true&&n.audience==='Student Council Portal (public)')}
function formatDate(value:string){if(!value)return 'Date to be announced';const d=new Date(`${value}T12:00:00`);return Number.isNaN(d.getTime())?value:d.toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'})}

export default function PublicPortal({onLogin}:{onLogin:()=>void}){
  const [query,setQuery]=useState('')
  const [tab,setTab]=useState<PortalTab>('all')
  const [mobileMenu,setMobileMenu]=useState(false)
  const [showAllCouncil,setShowAllCouncil]=useState(false)
  const [showAllEvents,setShowAllEvents]=useState(false)
  const [showAllNotices,setShowAllNotices]=useState(false)
  const [events,setEvents]=useState<CouncilEvent[]>(getPublicEvents)
  const [notices,setNotices]=useState<PublicNotice[]>(()=>supabase?[]:getPublicNotices())
  const [cmsContent,setCmsContent]=useState<WebsiteContent>(getWebsiteContent)
  const [teams,setTeams]=useState<PublicTeam[]>(getPublicTeams)
  const [clubs,setClubs]=useState<StudentClub[]>(studentClubs)
  const [achievements,setAchievements]=useState<PublicAchievement[]>(getPublicAchievements)
  useEffect(()=>{
    let alive=true
    const loadCloudTeams=async()=>{
      if(!supabase)return
      const {data,error}=await supabase.from('campus_sports_team_members')
        .select('id,team_name,sport,member_name,class_name,sort_order')
        .eq('is_published',true).order('sort_order',{ascending:true})
      if(error){console.error('[ASTRA] Could not load public sports teams:',error.message);return}
      if(!alive||!data)return
      const grouped=new Map<string,PublicTeam>()
      for(const row of data as any[]){
        const key=row.team_name
        if(!grouped.has(key))grouped.set(key,{id:key,name:key,category:row.sport,coach:'',season:'2026',members:[]})
        grouped.get(key)!.members.push({id:row.id,name:row.member_name,role:row.class_name})
      }
      setTeams(Array.from(grouped.values()))
    }
    const loadCloudClubs=async()=>{
      if(!supabase)return
      const {data,error}=await supabase.from('campus_clubs').select('id,slug,name,description,category,logo_path,status')
        .eq('status','active').order('name',{ascending:true})
      if(error){console.error('[ASTRA] Could not load public clubs:',error.message);return}
      if(!alive||!data)return
      setClubs((data as any[]).map(row=>({
        id:row.slug||row.id,name:row.name,subtitle:row.category||'Campus community',
        logo:row.logo_path||'/brand/astra-mark.png',status:'Active',
        description:row.description||'Campus community at ASTRA POINT.',team:[]
      })))
    }
    const loadCloudEvents=async()=>{
      if(!supabase)return
      const {data,error}=await supabase.from('campus_events').select('id,title,category,starts_at,venue,capacity,status')
        .in('status',['published','completed']).order('starts_at',{ascending:true})
      if(error){console.error('[ASTRA] Could not load public events:',error.message);return}
      if(!alive||!data)return
      setEvents((data as any[]).map(row=>({
        id:row.id,title:row.title,category:row.category||'Campus',
        date:row.starts_at?new Date(row.starts_at).toISOString().slice(0,10):'',
        time:row.starts_at?new Date(row.starts_at).toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'}):'Time to be announced',
        venue:row.venue||'To be confirmed',registrations:0,capacity:Number(row.capacity||0),
        status:row.status==='completed'?'Completed':'Published',color:'#8b2942'
      })))
    }
    const loadCloudNotices=async()=>{
      if(!supabase)return
      const {data,error}=await supabase.from('campus_announcements').select('id,title,body,status,audience,published_at,expires_at')
        .eq('status','published').eq('audience','all').or(`expires_at.is.null,expires_at.gt.${new Date().toISOString()}`)
        .order('published_at',{ascending:false})
      if(error){console.error('[ASTRA] Could not load public announcements:',error.message);return}
      if(!alive||!data)return
      setNotices((data as any[]).map(row=>({
        id:row.id,title:row.title,body:row.body,status:'Published',
        publicPortal:true,audience:'Student Council Portal (public)',
        updated:row.published_at||'',expiry:row.expires_at||''
      })))
    }
    if(supabase)void Promise.all([loadCloudTeams(),loadCloudClubs(),loadCloudEvents(),loadCloudNotices()])
    const channel=supabase?.channel('astra-public-portal-live-sync')
      .on('postgres_changes',{event:'*',schema:'public',table:'campus_sports_team_members'},()=>{void loadCloudTeams()})
      .on('postgres_changes',{event:'*',schema:'public',table:'campus_clubs'},()=>{void loadCloudClubs()})
      .on('postgres_changes',{event:'*',schema:'public',table:'campus_events'},()=>{void loadCloudEvents()})
      .on('postgres_changes',{event:'*',schema:'public',table:'campus_announcements'},()=>{void loadCloudNotices()})
      .subscribe()
    const refresh=()=>{setEvents(getPublicEvents());if(!supabase)setNotices(getPublicNotices());setCmsContent(getWebsiteContent());setTeams(getPublicTeams());setAchievements(getPublicAchievements())}
    const onStorage=(event:StorageEvent)=>{if(!event.key||event.key===EVENTS_KEY||event.key===NOTICES_KEY||event.key===WEBSITE_CMS_KEY||event.key===TEAMS_KEY||event.key===ACHIEVEMENTS_KEY)refresh()}
    window.addEventListener('storage',onStorage)
    window.addEventListener('astra-public-announcements-updated',refresh)
    window.addEventListener('astra-public-events-updated',refresh)
    window.addEventListener('astra-website-cms-updated',refresh)
    window.addEventListener('astra-public-teams-updated',refresh)
    window.addEventListener('astra-public-achievements-updated',refresh)
    return()=>{alive=false;if(channel)supabase?.removeChannel(channel);window.removeEventListener('storage',onStorage);window.removeEventListener('astra-public-announcements-updated',refresh);window.removeEventListener('astra-public-events-updated',refresh);window.removeEventListener('astra-website-cms-updated',refresh);window.removeEventListener('astra-public-teams-updated',refresh);window.removeEventListener('astra-public-achievements-updated',refresh)}
  },[])
  const groups=useMemo(()=>new Set(councilPeople.map(p=>p.group)).size,[ ])
  const filteredPeople=useMemo(()=>councilPeople.filter(p=>(p.name+' '+p.role+' '+p.group+' '+p.branch).toLowerCase().includes(query.trim().toLowerCase())),[query])
  const leadership=useMemo(()=>filteredPeople.filter(p=>p.group==='Council Leadership').slice(0,8),[filteredPeople])
  const upcomingEvents=useMemo(()=>events.filter(e=>e.status==='Published'&&(!e.date||e.date>=new Date().toISOString().slice(0,10))).sort((a,b)=>a.date.localeCompare(b.date)),[events])
  const portalEvents=useMemo(()=>[...events].sort((a,b)=>{
    const aUpcoming=a.status==='Published'&&a.date>=new Date().toISOString().slice(0,10)
    const bUpcoming=b.status==='Published'&&b.date>=new Date().toISOString().slice(0,10)
    if(aUpcoming!==bUpcoming)return aUpcoming?-1:1
    return aUpcoming?a.date.localeCompare(b.date):b.date.localeCompare(a.date)
  }),[events])
  const visibleEvents=showAllEvents?portalEvents:portalEvents.slice(0,3)
  const visibleNotices=showAllNotices?notices:notices.slice(0,3)
  const searching=query.trim().length>0
  const selectTab=(next:PortalTab)=>{
    setTab(next);if(next==='council')setShowAllCouncil(true);setMobileMenu(false)
    const target=next==='all'?'portal-home':next==='council'?'portal-council':next==='events'?'portal-events':next==='notices'?'portal-announcements':next==='services'?'portal-services':next==='clubs'?'portal-clubs':next==='teams'?'portal-teams':next==='hall-of-fame'?'portal-hall-of-fame':next==='gallery'?'portal-gallery':next==='about'?'portal-about':'portal-contact'
    document.getElementById(target)?.scrollIntoView({behavior:'smooth',block:'start'})
  }
  const sectionTitle=(kicker:string,title:string,description:string,icon:ReactNode)=><div className="student-section-heading"><div><span className="student-section-kicker">{kicker}</span><h2>{title}</h2><p>{description}</p></div><span className="student-section-mark">{icon}</span></div>
  return <main className={`public-portal student-portal ${tab==='all'?'is-home-view':'is-section-view'}`} data-active-tab={tab} id="portal-home">
    <header className="portal-nav">
      <a className="portal-brand council-brand" href="#portal-home" aria-label="Siddhant College Student Council home"><img className="council-crest" src="/brand/student-council-crest.jpg" alt="Siddhant College Student Council crest"/><span className="council-wordmark"><strong>SIDDHANT</strong><small>COLLEGE OF ENGINEERING</small><em>STUDENT COUNCIL</em></span></a>
      <span className="brand-divider" aria-hidden="true"/>
      <a className="portal-brand astra-brand" href="#portal-home" aria-label="ASTRA, The Developer Group"><img className="astra-mark" src="/brand/astra-mark.png" alt="ASTRA logo"/><span><strong>ASTRA</strong><small>THE DEVELOPER GROUP</small></span></a>
      <nav className={`portal-links ${mobileMenu?'is-open':''}`} aria-label="Student portal navigation">
        <button className={tab==='all'?'active':''} onClick={()=>selectTab('all')}>Home</button><button className={tab==='council'?'active':''} onClick={()=>selectTab('council')}>Council</button><button className={tab==='events'?'active':''} onClick={()=>selectTab('events')}>Events</button><button className={tab==='notices'?'active':''} onClick={()=>selectTab('notices')}>Announcements</button><button className={tab==='services'?'active':''} onClick={()=>selectTab('services')}>Services</button><button className={tab==='clubs'?'active':''} onClick={()=>selectTab('clubs')}>Clubs</button><button className={tab==='teams'?'active':''} onClick={()=>selectTab('teams')}>Teams</button><button className={tab==='hall-of-fame'?'active':''} onClick={()=>selectTab('hall-of-fame')}>Hall of Fame</button><button className={tab==='gallery'?'active':''} onClick={()=>selectTab('gallery')}>Gallery</button><button className={tab==='about'?'active':''} onClick={()=>selectTab('about')}>About</button><button className={tab==='contact'?'active':''} onClick={()=>selectTab('contact')}>Contact</button>
      </nav>
      <label className="nav-search" aria-label="Search the council directory"><Search size={17}/><input value={query} onChange={e=>{setQuery(e.target.value);if(e.target.value){setTab('council');setShowAllCouncil(true)}}} placeholder="Search council" onKeyDown={e=>{if(e.key==='Enter')selectTab('council')}}/></label>
      <button className="portal-login" onClick={onLogin}>Student login <ArrowRight size={15}/></button><button className="mobile-menu-toggle" aria-label={mobileMenu?'Close menu':'Open menu'} onClick={()=>setMobileMenu(v=>!v)}>{mobileMenu?<X size={22}/>:<Menu size={22}/>}</button>
    </header>

    <section className="portal-hero student-hero student-hero-centered">
      <div className="portal-hero-content">
        <span className="portal-eyebrow"><span className="hero-live-dot"/> SIDDHANT COLLEGE OF ENGINEERING · STUDENT COUNCIL</span>
        <h1>{cmsContent.headline}</h1>
        <figure className="student-hero-council-photo"><img src="/gallery/siddhant-college-student-council.jpg" alt="Siddhant College student council group photograph" fetchPriority="high"/><figcaption>Siddhant College of Engineering · Student Council</figcaption></figure>
        <p className="student-hero-subtitle">{cmsContent.subheadline}</p>
        <div className="portal-welcome-banner">{cmsContent.banner}</div>
        <p>A shared space to meet your representatives, discover campus events, read official announcements, and find student services — all in one place.</p>
        <div className="portal-hero-actions"><button className="portal-primary" onClick={()=>selectTab('council')}><Users size={16}/> Meet your council <ArrowRight size={16}/></button><button className="portal-secondary" onClick={onLogin}><CircleUserRound size={16}/> Student login</button></div>
        <div className="hero-trust-row"><ShieldCheck size={15}/><span>Public information is visible to everyone · Personal services require sign-in</span></div>
      </div>
      <aside className="student-hero-panel" aria-label="Student portal quick links">
        <div className="student-panel-top"><span className="student-panel-logo"><GraduationCap size={22}/></span><span className="student-panel-label">STUDENT COUNCIL PORTAL</span><span className="student-panel-status">PUBLIC</span></div>
        <div className="student-panel-title">Everything campus.<br/><strong>One portal.</strong></div><div className="student-panel-rule"/>
        <div className="student-panel-links"><button onClick={()=>selectTab('events')}><span className="student-mini-icon"><CalendarDays size={17}/></span><span><strong>Campus events</strong><small>{upcomingEvents.length?`${upcomingEvents.length} published event${upcomingEvents.length===1?'':'s'}`:'Discover published events'}</small></span><ChevronRight size={17}/></button><button onClick={()=>selectTab('council')}><span className="student-mini-icon"><Users size={17}/></span><span><strong>Your representatives</strong><small>Browse the council directory</small></span><ChevronRight size={17}/></button><button onClick={()=>selectTab('notices')}><span className="student-mini-icon"><Megaphone size={17}/></span><span><strong>Official announcements</strong><small>{notices.length?`${notices.length} public update${notices.length===1?'':'s'}`:'Read authorized updates'}</small></span><ChevronRight size={17}/></button><button onClick={()=>selectTab('services')}><span className="student-mini-icon"><BookOpen size={17}/></span><span><strong>Student services</strong><small>Find your student tools</small></span><ChevronRight size={17}/></button></div>
        <div className="student-panel-foot"><span><span className="student-panel-dot"/> Public portal</span><span>ASTRA POINT</span></div>
      </aside><div className="student-hero-orb orb-a"/><div className="student-hero-orb orb-b"/>
    </section>

    <section className="student-stats" aria-label="Live public portal summary"><div><span className="student-stat-icon"><Users size={19}/></span><span><strong>{councilPeople.length}</strong><small>Council directory entries</small></span></div><div><span className="student-stat-icon"><Trophy size={19}/></span><span><strong>{groups}</strong><small>Represented groups</small></span></div><div><span className="student-stat-icon"><Bell size={19}/></span><span><strong>{notices.length}</strong><small>Public announcements</small></span></div><div><span className="student-stat-icon"><CalendarDays size={19}/></span><span><strong>{upcomingEvents.length}</strong><small>Upcoming published events</small></span></div></section>

    <section className="portal-content student-content home-overview" id="portal-home-overview">
      <div className="home-overview-topline"><div><span className="student-section-kicker">THE CAMPUS PULSE</span><h2>What’s happening at Siddhant</h2><p>Everything worth knowing, in one clear view.</p></div><span className="home-overview-live"><span/> LIVE PORTAL</span></div>
      <div className="astra-constellation" aria-label="Interactive campus constellation">
        <div className="constellation-copy">
          <span className="constellation-kicker"><Sparkles size={14}/> THE ASTRA CONSTELLATION</span>
          <h3>One campus.<br/><em>Infinite possibilities.</em></h3>
          <p>Every event, team, idea and achievement is part of the same student community. Pick an orbit and explore.</p>
          <div className="constellation-live-line"><span className="constellation-live-dot"/> CAMPUS PULSE <span>·</span> LIVE OVERVIEW</div>
          <div className="constellation-metrics">
            <div><strong>{councilPeople.length.toString().padStart(2,'0')}</strong><small>PEOPLE</small></div>
            <div><strong>{upcomingEvents.length.toString().padStart(2,'0')}</strong><small>EVENTS</small></div>
            <div><strong>{clubs.length.toString().padStart(2,'0')}</strong><small>COMMUNITIES</small></div>
          </div>
        </div>
        <div className="constellation-stage" aria-label="Choose a campus destination">
          <div className="constellation-glow"/>
          <div className="constellation-ring constellation-ring-one"/>
          <div className="constellation-ring constellation-ring-two"/>
          <div className="constellation-ring constellation-ring-three"/>
          <div className="constellation-core"><img src="/brand/astra-mark.png" alt="ASTRA logo"/><span>ASTRA<br/><small>POINT</small></span></div>
          <button className="constellation-node node-council" onClick={()=>selectTab('council')} aria-label="Explore council"><Users size={18}/><span>Council</span></button>
          <button className="constellation-node node-events" onClick={()=>selectTab('events')} aria-label="Explore events"><CalendarDays size={18}/><span>Events</span></button>
          <button className="constellation-node node-clubs" onClick={()=>selectTab('clubs')} aria-label="Explore clubs"><BookOpen size={18}/><span>Clubs</span></button>
          <button className="constellation-node node-teams" onClick={()=>selectTab('teams')} aria-label="Explore teams"><Trophy size={18}/><span>Teams</span></button>
          <button className="constellation-node node-achievements" onClick={()=>selectTab('hall-of-fame')} aria-label="Explore Hall of Fame"><Award size={18}/><span>Hall of Fame</span></button>
          <span className="constellation-star star-one">✦</span><span className="constellation-star star-two">✧</span><span className="constellation-star star-three">✦</span>
        </div>
      </div>
      <div className="home-overview-grid">
        <article className="home-feature-card home-feature-burgundy"><div className="home-feature-orbit"/><span className="home-feature-kicker"><Megaphone size={14}/> FROM THE COUNCIL</span><h3>Stay connected<br/>to your campus.</h3><p>Official updates, student initiatives and important notices—all in one place.</p><button onClick={()=>selectTab('notices')}>Read announcements <ArrowRight size={15}/></button><span className="home-feature-watermark"><ShieldCheck size={74}/></span></article>
        <article className="home-spotlight-card"><div className="home-spotlight-head"><span className="home-overview-icon"><CalendarDays size={18}/></span><button onClick={()=>selectTab('events')}>All events <ArrowRight size={14}/></button></div><span className="home-card-eyebrow">CAMPUS CALENDAR</span><h3>Coming up</h3>{upcomingEvents.length?<div className="home-mini-list">{upcomingEvents.slice(0,2).map(e=><button key={e.id} onClick={()=>selectTab('events')}><span className="home-mini-date"><strong>{e.date?new Date(`${e.date}T12:00:00`).getDate():'—'}</strong><small>{e.date?new Date(`${e.date}T12:00:00`).toLocaleDateString('en-IN',{month:'short'}):'TBA'}</small></span><span className="home-mini-copy"><strong>{e.title}</strong><small>{e.dateLabel||formatDate(e.date)}</small></span><ChevronRight size={16}/></button>)}</div>:<div className="home-compact-empty"><CalendarClock size={20}/><span><strong>No upcoming events yet</strong><small>Published campus events will appear here.</small></span></div>}</article>
        <article className="home-spotlight-card home-notice-spotlight"><div className="home-spotlight-head"><span className="home-overview-icon"><Bell size={18}/></span><button onClick={()=>selectTab('notices')}>All updates <ArrowRight size={14}/></button></div><span className="home-card-eyebrow">LATEST UPDATES</span><h3>Noticeboard</h3>{notices.length?<div className="home-mini-list">{notices.slice(0,2).map(n=><button key={n.id} onClick={()=>selectTab('notices')}><span className="home-mini-notice"><Megaphone size={16}/></span><span className="home-mini-copy"><strong>{n.title}</strong><small>{n.updated||'Official council update'}</small></span><ChevronRight size={16}/></button>)}</div>:<div className="home-compact-empty"><Bell size={20}/><span><strong>Nothing new for now</strong><small>Official public announcements will appear here.</small></span></div>}</article>
      </div>
      <div className="home-explore-row"><div><span className="student-section-kicker">EXPLORE ASTRA POINT</span><h3>Your campus, closer.</h3><p>Jump straight to the people and communities that make campus life happen.</p></div><div className="home-explore-links"><button onClick={()=>selectTab('council')}><span><Users size={19}/></span><strong>Meet the council</strong><ArrowRight size={15}/></button><button onClick={()=>selectTab('clubs')}><span><BookOpen size={19}/></span><strong>Clubs & societies</strong><ArrowRight size={15}/></button><button onClick={()=>selectTab('teams')}><span><Trophy size={19}/></span><strong>College teams</strong><ArrowRight size={15}/></button><button onClick={()=>selectTab('hall-of-fame')}><span><Award size={19}/></span><strong>Hall of Fame</strong><ArrowRight size={15}/></button><button onClick={()=>selectTab('services')}><span><Sparkles size={19}/></span><strong>Student services</strong><ArrowRight size={15}/></button><button onClick={onLogin}><span><CircleUserRound size={19}/></span><strong>Student workspace</strong><ArrowRight size={15}/></button></div></div>
    </section>

    <section className="portal-content student-content" id="portal-announcements">
      {sectionTitle('STAY IN THE LOOP','Official announcements','Public notices appear here only after they are marked Published and explicitly addressed to the public student portal.',<Megaphone size={22}/>)}
      {visibleNotices.length?<div className="student-public-card-grid">{visibleNotices.map(n=><article className="student-public-card" key={n.id}><span className="student-public-card-icon"><Bell size={19}/></span><div><span className="student-card-meta">PUBLIC ANNOUNCEMENT{n.updated?` · ${n.updated}`:''}</span><h3>{n.title}</h3><p>{n.body}</p></div></article>)}</div>:<div className="student-empty-state"><span className="student-empty-icon"><Bell size={22}/></span><div><strong>No public announcements yet</strong><p>There are no verified public notices to display. Check back when the council publishes an update.</p></div></div>}
      {notices.length>3&&<button className="student-view-directory" onClick={()=>setShowAllNotices(v=>!v)}>{showAllNotices?'Show fewer announcements':'View all announcements'} <ArrowRight size={15}/></button>}
    </section>

    <section className="portal-content student-content" id="portal-events">
      {sectionTitle('CAMPUS LIFE','Events & activities','Explore upcoming plans and look back at completed campus events.',<CalendarDays size={22}/>)}
      {visibleEvents.length?<div className="student-public-card-grid">{visibleEvents.map(e=><article className="student-public-card student-event-card" key={e.id}><span className="student-public-card-icon"><CalendarCheck2 size={19}/></span><div><span className="student-card-meta">{e.category||'CAMPUS EVENT'} · {e.dateLabel||formatDate(e.date)}</span><h3>{e.title}</h3><p>{e.venue?`${e.venue} · `:''}{e.time||'Time to be announced'}</p></div><span className={`student-event-pill ${e.status==='Completed'?'is-completed':''}`}>{e.status==='Completed'?'Completed':'Upcoming'}</span></article>)}</div>:<div className="student-empty-state"><span className="student-empty-icon"><CalendarClock size={22}/></span><div><strong>No campus events available</strong><p>Campus events will appear here when the council adds or publishes them.</p></div><button className="student-outline-action" onClick={onLogin}>Student login <ArrowRight size={14}/></button></div>}
      {portalEvents.length>3&&<button className="student-view-directory" onClick={()=>setShowAllEvents(v=>!v)}>{showAllEvents?'Show fewer events':'View all events'} <ArrowRight size={15}/></button>}
    </section>

    <section className="portal-content student-content" id="portal-council">
      {sectionTitle('MEET YOUR REPRESENTATIVES','Student Council team','Browse the current council directory. Search by name, role, committee, or department.',<Users size={22}/>)}
      <label className="student-directory-search"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Find a council member or committee…"/>{query&&<button onClick={()=>setQuery('')} aria-label="Clear search"><X size={15}/></button>}</label>
      {filteredPeople.length?<div className="student-team-grid">{(searching||showAllCouncil?filteredPeople:leadership).map(person=><article className="student-person-card" key={person.serial}><span className={`student-person-avatar ${person.kind==='faculty'?'faculty':''}`}>{person.name.split(/\s+/).map(n=>n[0]).slice(0,2).join('').toUpperCase()}</span><div className="student-person-info"><span className="student-person-group">{person.group}</span><h3>{person.name}</h3><p>{person.role}</p><span className="student-person-meta">{person.className!=='—'?`${person.className} · `:''}{person.branch}</span></div></article>)}</div>:<div className="student-empty-state"><span className="student-empty-icon"><Search size={20}/></span><div><strong>No council members match</strong><p>Try another name, role, committee, or department.</p></div></div>}
      {!searching&&!showAllCouncil&&filteredPeople.length>leadership.length&&<button className="student-view-directory" onClick={()=>setShowAllCouncil(true)}>Browse full directory <ArrowRight size={15}/></button>}
    </section>

    <section className="portal-content student-content" id="portal-services">
      {sectionTitle('YOUR STUDENT SPACE','Student services','Choose a service to sign in. Available tools depend on your assigned account and role.',<Sparkles size={22}/>)}
      <div className="student-services-grid"><button className="student-service-card" onClick={onLogin}><span className="service-icon"><ClipboardCheck size={20}/></span><strong>My submissions</strong><small>Track forms and requests</small><ArrowRight size={16}/></button><button className="student-service-card" onClick={onLogin}><span className="service-icon"><Award size={20}/></span><strong>Certificates</strong><small>View certificate options</small><ArrowRight size={16}/></button><button className="student-service-card" onClick={onLogin}><span className="service-icon"><MessageSquareText size={20}/></span><strong>Feedback</strong><small>Share student feedback</small><ArrowRight size={16}/></button><button className="student-service-card" onClick={()=>selectTab('teams')}><span className="service-icon"><Users size={20}/></span><strong>College teams</strong><small>Meet our representatives</small><ArrowRight size={16}/></button><button className="student-service-card" onClick={()=>selectTab('hall-of-fame')}><span className="service-icon"><Trophy size={20}/></span><strong>Hall of Fame</strong><small>Celebrate student achievements</small><ArrowRight size={16}/></button><button className="student-service-card" onClick={()=>selectTab('clubs')}><span className="service-icon"><BookOpen size={20}/></span><strong>Clubs & societies</strong><small>Explore student communities</small><ArrowRight size={16}/></button></div>
    </section>

    <section className="portal-content student-content" id="portal-clubs">
      {sectionTitle('CAMPUS COMMUNITIES','Clubs & societies','Meet the student communities and their published leadership teams.',<Users size={22}/>)}
      <div className="student-clubs-grid">{clubs.map(club=><article className="student-club-card" key={club.id}>
        <div className="student-club-brand"><img src={club.logo} alt={`${club.name} logo`} loading="lazy"/><div><span className={`student-club-status ${club.status==='Launching soon'?'is-launching':''}`}>{club.status}</span><h3>{club.name}</h3><p>{club.subtitle}</p></div></div>
        <p className="student-club-description">{club.description}</p>
        {club.team.length>0?<details className="student-club-team"><summary>Meet the team <span>{club.team.length} roles</span></summary><div className="student-club-members">{club.team.map(member=><div key={`${club.id}-${member.name}-${member.role}`}><strong>{member.name}</strong><span>{member.role}</span></div>)}</div></details>:<div className="student-club-coming-soon">Team announcement coming soon.</div>}
      </article>)}</div>
    </section>

    <section className="portal-content student-content" id="portal-teams">
      {sectionTitle('COLLEGE REPRESENTATION','Our Teams','Meet students representing the college in sports, technical competitions, cultural events and more.',<Users size={22}/>)}
      {teams.length>0?<div className="student-clubs-grid">{teams.map(team=><article className="student-club-card" key={team.id}>
        <div className="student-club-brand"><span className="student-team-icon"><Users size={24}/></span><div><span className="student-club-status">{team.category} · {team.season}</span><h3>{team.name}</h3><p>{team.coach?`Coach / mentor: ${team.coach}`:'College representatives'}</p></div></div>
        <details className="student-club-team"><summary>View team roster <span>{team.members.length} members</span></summary>
          {team.members.length>0?<div className="student-club-members">{team.members.map(member=><div key={member.id}><strong>{member.name}</strong><span>{member.role}</span></div>)}</div>:<div className="student-club-coming-soon">Roster will appear when team members are added by an administrator.</div>}
        </details>
      </article>)}</div>:<div className="student-empty-state"><Users size={24}/><strong>Teams are being prepared</strong><span>Official college teams and rosters will appear here once added by an administrator.</span></div>}
    </section>

    <section className="portal-content student-content" id="portal-hall-of-fame">
      {sectionTitle('STUDENT ACHIEVEMENTS','Hall of Fame','Celebrating champions and students representing Siddhant College at significant competitions.',<Trophy size={22}/>)}
      {achievements.length>0?<><div className="student-achievement-grid">{achievements.filter(a=>a.featured).map(a=><article className="student-achievement-card is-featured" key={a.id}><span className="student-card-meta">FEATURED CHAMPION · {a.category}</span><h3>{a.title}</h3><strong>{a.person}</strong><p>{a.result}</p><small>{a.competition} · {a.date}</small>{a.story&&<p>{a.story}</p>}</article>)}</div><div className="student-achievement-grid">{achievements.map(a=><article className="student-achievement-card" key={a.id}><span className="student-card-meta">{a.category} · {a.competition}</span><h3>{a.title}</h3><strong>{a.person}</strong><p>{a.result}</p>{a.story&&<p>{a.story}</p>}<small>Published {a.date}</small></article>)}</div></>:<div className="student-empty-state"><Trophy size={24}/><strong>Every achievement deserves recognition</strong><span>Approved winners and college representatives will appear here after an administrator publishes their achievements.</span></div>}
    </section>

    <section className="portal-content student-content" id="portal-gallery">
      {sectionTitle('CAMPUS MEMORIES','Gallery','A place for real campus moments and approved council event photos.',<ImageIcon size={22}/>)}
      <figure className="student-gallery-feature">
        <img src="/gallery/siddhant-college-student-council.jpg" alt="Student council members, faculty and staff gathered outside Siddhant College of Engineering" loading="lazy" />
        <figcaption><span className="student-card-meta">CAMPUS MEMORIES</span><strong>Siddhant College of Engineering · Student Council</strong><small>A real group photograph shared for the ASTRA POINT campus gallery.</small></figcaption>
      </figure>
    </section>

    <section className="portal-content student-content student-about" id="portal-about">
      {sectionTitle('ABOUT THE PORTAL','A clearer home for student life',cmsContent.about,<Info size={22}/>)}
      <div className="student-about-grid"><article><span className="student-about-icon"><Users size={20}/></span><h3>Meet the council</h3><p>Find representatives by name, role, group or department using the current council directory.</p></article><article><span className="student-about-icon"><Megaphone size={20}/></span><h3>Trusted updates</h3><p>Only notices explicitly published for the public portal appear in the announcement feed.</p></article><article><span className="student-about-icon"><ShieldCheck size={20}/></span><h3>Student-first access</h3><p>Public information is open to visitors. Personal tools continue to use the existing login flow.</p></article></div>
    </section>

    <section className="portal-content student-content" id="portal-contact">
      {sectionTitle('GET IN TOUCH','Contact the council','Use the existing student account to access internal council services. Public contact details can be added when an official channel is supplied.',<Mail size={22}/>)}
      <div className="student-contact-panel"><span className="student-contact-icon"><Compass size={22}/></span><div><strong>Need help or want to reach the council?</strong><p>No public email address or contact channel is configured in the current project, so we have not invented one.</p></div><button className="student-outline-action" onClick={onLogin}>Open student login <ArrowRight size={14}/></button></div>
    </section>

    <footer className="portal-footer student-footer"><div className="footer-brands"><img src="/brand/student-council-crest.jpg" alt="Student Council crest"/><span className="footer-divider"/><img src="/brand/astra-mark.png" alt="ASTRA logo"/><span><strong>ASTRA POINT</strong><small>Student Council Management</small></span></div><span>Public information only · Private services require authentication</span><button onClick={onLogin}>Student login <ArrowRight size={14}/></button></footer>
    
  </main>
}
