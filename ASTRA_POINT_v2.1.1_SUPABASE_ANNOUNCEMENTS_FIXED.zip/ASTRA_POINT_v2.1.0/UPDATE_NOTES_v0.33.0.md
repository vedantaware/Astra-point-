# ASTRA POINT v0.33.0 — Relational Workflows

## Converted to direct relational CRUD
- Teams and roster membership use `astra.teams`, `astra.team_members`, and approved profile lookup.
- Budget allocations and expenses use `astra.budgets` and `astra.expenses`; expense review requires a separate authorized reviewer.
- Meetings and minutes use `astra.meetings`; updates include optimistic version checks.
- Attendance can be recorded for the signed-in user against a meeting in `astra.attendance`.
- Feedback forms now store question prompts in JSONB and submissions persist answers in `astra.feedback_responses`; anonymous responses omit respondent IDs, repeated submissions use idempotency keys, and closed forms reject new submissions.
- Notifications load from the signed-in user's `astra.notifications` inbox, support read-state updates, and authorized staff can send targeted messages.
- Audit history is read from `astra.audit_logs`; database triggers record mutations across core workflow tables, while client-side update/delete and direct insert policies are removed for audit rows.

## Concurrency and permissions
- `version` columns and conditional updates are added for teams, budgets, expenses, meetings and feedback forms. Stale updates return a conflict instead of silently overwriting the latest row.
- RLS remains the enforcement layer. UI role switching is only a demo affordance and cannot grant database privileges.
- Feedback submission requires the target form to remain Open. Attendance self-service is scoped to the authenticated user. Team roster membership references real Auth users.

## Verification status
- `node scripts/verify-role-policy-matrix.mjs` passes the static regression checks for 10 UI roles and key RLS invariants.
- Supabase schema verification confirmed the version columns, audit triggers, feedback/notification policies, and role-scoped policies are present.
- The live Supabase project currently has zero Auth users and zero `astra.profiles` rows. Actual signed-in RLS impersonation across all roles cannot yet run; provision test accounts before production acceptance.
- `npm install` timed out and `npm install --offline` failed because dependencies are not cached. Therefore `npm run build` and browser end-to-end tests could not be successfully executed in this environment. Install dependencies in a network-enabled environment and run the build/E2E suite before release.
