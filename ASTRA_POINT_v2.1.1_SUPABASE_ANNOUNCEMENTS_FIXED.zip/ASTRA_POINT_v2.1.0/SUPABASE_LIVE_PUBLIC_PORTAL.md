# ASTRA POINT — Supabase live public portal

This build makes the public portal read these Supabase tables directly and subscribe to Supabase Realtime:
- `public.campus_clubs`: active clubs
- `public.campus_events`: published/completed events
- `public.campus_announcements`: published announcements with `audience = 'All'` and not expired
- `public.campus_sports_team_members`: rows with `is_published = true`

Changes to these tables are re-fetched automatically when Realtime sends a database change. The app uses the existing configured `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY`; never put a service-role key in the browser.

## Important scope
This is the live public feed for the four listed content areas, not a promise that every table in the database is public. Private student records, authentication data, internal council notices, submissions, audit logs, and role-protected admin data must remain private and should not be exposed to the public website. Other public portal sections such as council directory, website CMS, gallery and achievements still need their own explicit data-source integrations before they can be managed solely by Supabase.

## Publish
Deploy this updated source ZIP to the same Vercel project with the existing Supabase environment variables. Do not reset or recreate the database. Apply the included migration only if the matching live policies/publication have not already been applied; this migration is idempotent for policies and Realtime table membership.
