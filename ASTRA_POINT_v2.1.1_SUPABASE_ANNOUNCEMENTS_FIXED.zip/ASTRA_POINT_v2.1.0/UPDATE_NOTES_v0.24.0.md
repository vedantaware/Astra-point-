# ASTRA POINT v0.24.0 — public student portal visibility fix

## Changes
- Added public Student Portal navigation links for **Teams** and **Hall of Fame**.
- Added a public Teams section reading the same local browser key used by the admin Teams workspace (`astra-point-campus-teams-v1`).
- Added a public Hall of Fame section reading approved/published records from `astra-point-achievement-records-v1`; featured records are highlighted.
- Added the existing real student council group photograph directly below the homepage headline/tagline.
- Added responsive styling for the hero photograph, teams and achievements.
- Preserved the existing project, login flow, and other modules.

## Important data behavior
- Admin and public portal share these records only within the same browser profile using localStorage. They are not yet shared across devices.
- The public Hall of Fame intentionally shows only `Published` achievements. Draft, in-review and returned submissions remain hidden.
- No remote Supabase data was changed.
