# ASTRA POINT v2.1.0

- Added a platform-admin-only Student Accounts workspace.
- Student creation uses a secure server-side Edge Function and email invitation flow.
- Prefilled the requested test student details (Vedant Aware, vedantaware11@gmail.com, PRN 12345, AIML, SE); edit before sending if needed.
- Corrected login profile lookup to `public.astra_user_profiles`.
- Corrected shared cloud state to `public.astra_app_state`.
- Connected core event reads/writes, profile recipient lookup, notification inbox/read state and admin audit reads to the active campus schema.
- Updated `.env.example` to the connected ASTRA POINT Supabase project. Removed the local `.env.local` file from the deliverable.
- No Auth invite is automatically sent during install or app startup.
