# ASTRA POINT v0.28.0 — ASTRA Constellation

## Homepage enhancement
- Added an interactive, animated ASTRA Constellation campus navigation experience to the public homepage.
- Added clickable orbital shortcuts to Council, Events, Clubs, Teams, and Hall of Fame using existing portal navigation state.
- Added live summary counts sourced from the current council directory, published upcoming events, and existing club catalogue.
- Uses the existing official ASTRA mark asset and existing ivory/burgundy brand palette.
- Responsive layout for desktop and mobile, with `prefers-reduced-motion` support.
- Existing login flow, CMS content, homepage sections, and data sources remain unchanged.

## Validation
- Source files updated; build not run in this workspace because dependencies are not installed.
- Run `npm install` and `npm run build` locally to validate the TypeScript/Vite production build.
