# Superseded update note

See `UPDATE_NOTES_v0.23.0.md` for the latest source changes and verified limitations.
