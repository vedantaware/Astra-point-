# ASTRA POINT v0.30.0 — Live ASTRA database modules

## Connected modules
- **Events:** reads `astra.events`; creating an event inserts a Draft record into Supabase.
- **Approvals:** reads pending records from `astra.approvals`; includes a request form; decisions update the approval and append to `astra.approval_history`.
- **Announcements:** reads `astra.announcements`; create draft/published announcements, publish drafts, and delete records through Supabase.
- **Auth:** uses Supabase Auth session and the `astra.profiles` role record.

## Setup
The ZIP includes `.env.local` configured for the ASTRA project's URL and publishable key. The publishable key is designed for browser use; RLS remains mandatory. Never add a `service_role` or secret key to frontend files.

Install dependencies and run:

```bash
npm install
npm run dev
```

## Important limitations
- A production build could not be run in this environment because package installation timed out and external network DNS was unavailable.
- Existing users without `astra.profiles` rows default to the low-privilege `student_participant` UI role. An authorized administrator must assign their actual role in `astra.profiles`.
- Email delivery, anonymous public-portal feed access, scheduled publishing, task sync and the other operational modules are not included in this phase.
- The `astra` schema is configured for PostgREST via the database authenticator role setting. If API requests return a schema-cache error, verify `astra` is listed under Supabase Project Settings → API → Exposed schemas and reload the PostgREST schema cache.
