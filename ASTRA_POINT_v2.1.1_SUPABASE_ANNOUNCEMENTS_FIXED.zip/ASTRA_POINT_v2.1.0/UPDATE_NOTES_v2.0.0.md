# ASTRA POINT v2.0.0 — Student Digital Campus foundation

## Preserved
- Existing public ASTRA POINT homepage, branding assets, typography, colour system, and responsive styles.
- Existing Super Admin workspace, existing modules, Supabase client configuration, and migration history.
- Existing Supabase records are not modified by this code upgrade. No migration was applied to a live project.

## Added
- Role-aware Supabase sign-in for active student and staff roles; the local/offline sign-in remains Super Admin-only.
- Student navigation for My Projects, Help Desk, Academic Hub, and My Activity.
- Personal project draft creation with description, technologies, GitHub URL, and live demo URL.
- Personal help-request submission and request history.
- Academic Hub shortcuts to existing Notices, Events, Certificates, and Clubs modules.
- Personal student workspace state uses the existing owner-scoped `astra.app_state` storage and its existing RLS policy.
- Responsive student workspace cards and forms.

## Important implementation boundary
This is the first upgrade milestone, not a claim that all requested campus workflows are production-complete. Project drafts and help requests are stored as a private per-user workspace payload. They are not yet relational records with admin moderation, assignment, status transitions, uploads, or public publishing. Certificate verification, event registration, notification centre, saved notices, marketplace, lost & found, idea hub, team finder, and volunteering workflows remain follow-on milestones.

## Supabase setup
- Student/staff access requires Supabase Auth and an active `astra.profiles` row with a supported role.
- Existing `astra.app_state` owner-scoped RLS migration must already be applied for private cloud sync.
- Do not expose a service-role key in the browser. Only the publishable/anon key belongs in `VITE_SUPABASE_PUBLISHABLE_KEY`.
- No database migration was applied and no remote data was changed.

## Verification
- TypeScript/TSX source syntax checked with the installed TypeScript transpiler.
- Full dependency install and production build could not be completed in this environment; network/package installation timed out. Run `npm install` and `npm run build` locally before deployment.
