# v2.2.0 — Supabase live public portal

- Public Clubs now load from `public.campus_clubs` (active rows).
- Public Events load from `public.campus_events` (published/completed rows).
- Public Announcements load from `public.campus_announcements` (published, audience `All`, unexpired).
- Public Sports Teams load from `public.campus_sports_team_members` (published members).
- Added Supabase Realtime subscriptions to refresh these four public sections after database changes.
- Existing database records are preserved. No reset or destructive migration.
- Council directory, CMS, gallery and achievements are not yet universally database-driven; see `SUPABASE_LIVE_PUBLIC_PORTAL.md`.
