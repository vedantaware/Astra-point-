# ASTRA POINT — Council OS

## v0.19.0 — Approved Student Portal homepage

- Applied the approved cream + wine-red hybrid portal direction with a centered hero, wide responsive navigation, and login at the top.
- Added all requested public sections: council, events, announcements, student services, live statistics, gallery, about, and contact.
- Council cards and counts derive from the existing council roster; public event cards read only `Published` event records, and announcement cards require both `Published` status and explicit public-portal audience flags.
- Added live refresh events for local prototype event and announcement changes. No database schema, Supabase data, auth, accounts, or council roster was modified.
- Gallery deliberately displays an empty state until real/approved campus photos are available; contact does not invent an email address.
- The current app's events and notices are browser-local prototype records. This homepage does **not** claim to read from Supabase; remote/live public feeds require a verified existing backend integration.
- **Verification:** all TS/TSX files passed syntax transpilation and CSS braces are balanced. Full production build and browser/device tests remain unverified because project dependencies are not installed in this environment.

## v0.18.0 — Clean data + Student Portal front door

- Rebuilt the pre-login public screen as a student portal with a responsive hero, student-service shortcuts, a searchable council directory sourced from the existing council roster, and dedicated announcements/events areas.
- Removed all seeded/sample operational records from events, tasks, approvals, meetings, budget, notices, media, feedback, inventory, partnerships, elections, rankings, hall of fame, clubs, submissions, certificate records, and audit preview.
- Public announcements and events now show honest empty states rather than placeholder content.
- Added a one-time browser cleanup for keys prefixed `astra-point-demo-`, `astra-demo-`, and `astra-point-scms-budget-`.
- The cleanup deliberately preserves local authentication sessions/accounts, theme and dashboard preferences, the existing council roster, Supabase configuration, and remote Supabase data.
- Added clean empty states and removed the hard-coded sample registration chart.
- **Verification:** TS/TSX syntax transpilation passed. Full build and browser/device tests remain unverified because dependency installation timed out in this environment.


## v0.17.0 — ASTRA POINT command-surface upgrade

- Added a global command palette with `Ctrl/⌘ K`, Escape-to-close, and role-filtered navigation results.
- Global search can find accessible pages, events, tasks, and council members; opening a result routes to its workspace.
- Added a Calendar workspace with timeline/list modes combining event dates and task deadlines.
- Added drag-and-drop ordering for role-dashboard metric cards, persisted per role in browser storage.
- Replaced the empty notification panel with actionable local demo reminders derived from pending approvals, open tasks, and events in review.
- Added an online/offline indicator and retained browser-local demo state; removed the startup loop that deleted keys containing `demo`.
- First-run demo seeds now include sample events, tasks, and approvals; dashboard headline metrics now reflect the displayed event/task records rather than fabricated additions.
- Added refined motion, responsive command palette/calendar layouts, focus states, and reduced-motion support.
- No Supabase migrations, live records, credentials, or environment configuration were changed.
- **Verification status:** static source checks and production build still need to complete. Prototype actions remain local unless the existing backend integration explicitly implements them.


A fresh React + TypeScript + Vite starter for ASTRA POINT, the Student Council Management System and student activity operations platform.

## Run locally
- Install Node.js 20+.
- In this folder run `npm install`
- Run `npm run dev`
- Create a production build with `npm run build`

## Current implementation
- Responsive ASTRA POINT workspace with role-specific dashboards and all existing module routes.
- Pre-login Student Council Portal with searchable council roster and explicit empty states for unconfigured public events and announcements.
- Operational lists start empty; no sample events, approvals, tasks, meetings, budget requests, media, feedback, inventory, partnerships, elections, rankings, or certificate records are seeded.
- Local-only workflows remain prototype features until their backend persistence is connected.
- Existing local authentication accounts and council roster are preserved.

## Important
This project is still a UI/workflow foundation, not a fully verified production system. Several operational workflows are browser-local until their server integrations are completed. Supabase queries/RLS, notifications, file storage, certificate delivery, and production-grade workflows must be tested against the authorized database before release. The one-time browser cleanup removes only explicitly demo-prefixed local keys; it does not connect to or modify Supabase.

## Identity
ASTRA — The Developer Group · Public-facing brand: COSMIC ASTRA  
Contact: BuildWithAstra@gmail.com · Instagram: @cosmiicastraa

## Product boundary
ASTRA POINT is not automatically a full academic ERP. Do not add exam, marksheet, fee, payroll or timetable modules without explicit approval. Preserve any authorized existing Supabase configuration if connecting a real backend.

## Event lifecycle workflow
Open **Events** and use the **Event workflow** panel. The workflow UI supports two-stage review, return-for-revision, rejection with reason, publishing, registration closure, completion/cancellation actions, a 48-hour client-side SLA indicator and a local audit timeline. These are browser-local transitions, not durable or secure production workflows. See `docs/EVENT_LIFECYCLE_WORKFLOW.md` and `docs/BUILD_STATUS.md`.

## Official council data
The Council directory is populated from the uploaded Siddhant College of Engineering Student Council Selection Committee Report dated 21 August 2026. It includes search, filters by student/faculty and committee group, and verification flags for ambiguous scan transcriptions. See `docs/COUNCIL_DATA_SOURCE.md`. The council roster is a frontend source file and is not database-persisted or protected by server-side access control.

## Roles and data access
A proposed Roles page now appears under Operations, with a draft permission matrix, role profiles, data entity overview and local-only guardrail toggles. SQL schema draft: `supabase/migrations/202610120001_astra_roles_and_data.sql`. The migration enables RLS without permissive policies (fail-closed); it is not deployment-ready until policies and trusted transition functions are designed, reviewed and tested. No database was connected or modified.

## Username/password authentication (implementation draft)
The app entry now uses `src/AuthRoot.tsx` for username/password sign-in and admin-only account creation. Auth uses the isolated `astra_access_profiles` table and `supabase/functions/astra-admin-users/index.ts`. SQL is in `supabase/migrations/202610120002_astra_point_username_auth.sql`. This is not live-connected by default: set environment values only after the intended backend is confirmed, deploy the additive migration/function, bootstrap the first admin securely, and run the tests in `docs/AUTH_IMPLEMENTATION.md`. The inspected Supabase project contains unrelated existing apps/data, so no live changes were made.

**Deployment status:** code package only. Live Supabase was inspected but not changed because the available active project contains existing unrelated application data. Dependency installation timed out; build and live RLS tests remain unverified. First-admin bootstrap is deliberately not automated and must be handled through a trusted operator-only process.

## Phase 2 UI/UX implementation (2026-10-12)

This iteration implements the approved UI direction: minimal interface, dark/light theme switch, split-screen sign-in layout, role-aware navigation, responsive sidebar, a mock notification center, and Meetings/Notices module entry screens. The app remains in prototype mode until the Supabase backend is intentionally configured. All demo content and interactions are local and must not be treated as verified institutional records.

### Phase 2 verification status
- Source changes and CSS added; no database or Supabase project was modified.
- Dependency installation timed out in this environment, so the production build and browser-level responsive checks could not be run here.
- Role-aware navigation is presentation only. Authorization must be enforced server-side with RLS and trusted functions during the later backend phase.
- The split-screen login is a UI treatment around the existing auth code; live login still requires correctly configured Supabase and deployed schema/function.


## Phase 2 frontend prototype

See `docs/PHASE_2_COMPLETION.md` for the screen inventory, local interactions, and validation boundaries. The frontend is intended to be explored using the demo-role selector when Supabase environment variables are absent. Demo changes stay in browser memory and are not persisted.

Run locally after dependencies are available:

```bash
npm install
npm run dev
npm run build
```

No database migration should be applied as part of Phase 2.

## Public Student Council Portal prototype

The unauthenticated start page is now the public Student Council Portal. It has a member-login entry point, public announcement cards, and preview sections for upcoming events and the council directory. Only explicitly published announcements whose audience is `Student Council Portal (public)` are rendered there. The internal announcement composer supports audience, priority, visibility, acknowledgement and delivery-preview controls. Prototype announcement data is stored in browser local storage only; this is not production persistence or security. Do not publish sensitive information. Public access and all recipient targeting must be enforced server-side when backend work begins.


## Full SCMS coverage prototype — v0.9.0
This release expands the management UI with dedicated Inventory, Partnerships, Elections and Audit workspaces. Combined with existing Council, Committees, Events, Tasks, Meetings, Approvals, Budget, Notices, Media, Certificates, Feedback, Reports and Roles, this provides a broader full-management-system prototype.

### Important module boundaries
- Inventory tracks illustrative assets and local status changes; it is not a procurement or custody ledger.
- Partnerships tracks outreach stages; a prospect is not a confirmed sponsor commitment.
- Elections supports nomination placeholders and UI status changes only; it does not run secure ballots or publish verified results.
- Audit displays illustrative examples only; it is not a tamper-resistant or server-generated audit log.
- The public Student Council Portal uses the actual supplied logo assets and reserves a blank team-photo area.
- All module records remain local demo state; refresh may discard changes.

### Full-system specification
Read `docs/FULL_SCMS_MODULE_SPEC.md` for the intended module boundaries, connected workflows, role model, acceptance criteria and database-later approach. No migrations have been applied. Do not connect to or alter any Supabase project until the target backend is explicitly confirmed and its existing schema/RLS has been audited.


## v0.10.1 — Role-specific dashboard UI

The platform administrator retains the full council overview. Institutional approvers, faculty coordinators, council presidents, event organizers, treasurers, committee members, student participants, and auditors now see a role-specific overview with tailored metrics and quick links. These are frontend prototype views and demo data; authorization must still be enforced by Supabase policies and backend functions before production use.


## v0.11.0 Phase A implementation slice

- Added a student self-registration request form to the public portal.
- Added a role-limited Student Verification queue for platform administrators, institutional approvers and faculty coordinators.
- Demo applications can be marked verified or rejected in the browser prototype.
- **Important:** these requests and decisions use browser localStorage only. They do not create Supabase Auth users, do not verify identity, and do not grant real access. Do not enter real/sensitive student data. Production self-registration requires a reviewed backend endpoint, verification process, audit records and RLS policies.
- No Supabase schema, credentials, connection, or data was changed.


## Letter Studio (v0.12.0)
- Added a letter builder using the uploaded Siddhant College letterhead layout and emblem assets.
- Users can enter/paste content, choose a signatory title block, print/save the document as PDF, or route a draft to a selected approver.
- Approval queue and draft status are browser-local prototype data only. No actual signature is embedded and no email/workflow backend is connected.
- Print dialog provides “Save as PDF” in supported browsers.

## v0.13.0 — Feature-first demo workspace expansion

- Added an in-workspace demo-role switcher for all nine prototype roles. It is shown only in demo mode and is explicitly not an authorization control.
- Added student-facing Rankings, Hall of Fame, Clubs, My Submissions, and My Profile pages to the Student Portal navigation.
- Added demo interactions for CSV export of rankings, local club join requests, form submission tracking, and profile editing.
- Persisted core demo Events, Tasks, and Approvals state to browser localStorage so basic workflow edits survive refresh.
- Kept the existing Letter Studio and existing management workspaces; no Supabase migrations or database changes were made.
- All new content is clearly illustrative/demo data. No real logins, backend persistence, secure voting, or production approval workflows are introduced by this release.

### v0.13.0 verification
- TypeScript/JSX transpilation syntax check: passed for source files.
- `npm run build`: not verified. Dependency installation timed out and the current environment lacks installed React, Vite, Recharts, Lucide and Supabase packages; Vercel must run the full build after installing dependencies.
- Database impact: none. Supabase migrations/configuration were not changed.

## v0.14.0 — demo Certificate Studio
- Adds batch setup with event, certificate type, college or club-specific template branding, approval policy, delivery intent, and selected illustrative recipients.
- Adds simulated approval-before-issuance, local certificate register, printable certificate preview, CSV export, and duplicate-safe issuance within a batch.
- Adds a Club Lead demo role restricted in the UI to the sample Innovation Club.
- **No Supabase calls or database migrations were applied.** Email is a simulated queue/status only; this prototype does not send messages.
- Verification details and known blockers: `docs/BUILD_STATUS.md`.


## v0.15.0 — bug-fix pass

See `docs/BUGFIX_REPORT_v0.15.0.md` for fixes, limitations, and deployment prerequisites. This update accepts email or username at login, escapes certificate print content, hardens CSV downloads against spreadsheet formula injection, records demo approval decisions locally, and corrects the visible version label. This is not a production-readiness certification; the build could not be run because dependency installation timed out. No live Supabase project was changed.


## Local account login (v0.16.1)

Supabase Authentication is not used by the login screen. Initial credentials for the 66 SCMS roster accounts and one ASTRA POINT administrator are in `ASTRA_POINT_LOCAL_LOGIN_CREDENTIALS.csv` (also under `docs/`). The account hashes are bundled in `src/localAuth.ts`. Admin-created accounts are saved only in the current browser's localStorage.

**Prototype limitation:** this client-side login is not suitable for protecting production or sensitive data because client code and local storage can be inspected or altered. It is intended for a private demonstration as requested. Database/data features remain otherwise unchanged.


### v0.19.1 gallery update
Added the provided real college group photograph to the public Campus Gallery. No remote Supabase data or auth settings changed.


## v0.23.0 local update

See `UPDATE_NOTES_v0.23.0.md` for Teams and Website CMS details, run steps, and testing limitations.


## Supabase live connection (v0.25.0)

See [`LIVE_SUPABASE_SETUP.md`](./LIVE_SUPABASE_SETUP.md) for the configured project, authentication, live-sync, role bootstrap, and validation notes. Never add a service-role key to a client-side Vite environment file.

## ASTRA POINT v2.0.0 — Student Digital Campus foundation
- Student and staff Supabase Auth sessions now resolve to role-specific workspaces; offline/local mode remains restricted to the Super Admin.
- Student participants have personal Project Showcase drafts, Help Desk request history, Academic Hub shortcuts, and My Activity.
- Personal student workspace records use owner-scoped `astra.app_state` storage and the existing RLS policies.
- See `UPDATE_NOTES_v2.0.0.md` for the exact implementation boundary and remaining milestones.
- The distributable ZIP intentionally excludes `.env.local`; copy `.env.example` to `.env.local` and add your own Supabase URL and publishable key locally. Never share `.env.local` or commit secrets.

## ASTRA POINT 2.1.0 — Connected campus backend and student invitations

This package is configured for the connected Supabase project shown in `.env.example` (`noobyuyuwcjghyxszauq`). See [`STUDENT_ACCOUNT_SETUP.md`](./STUDENT_ACCOUNT_SETUP.md) for setup and student invitations. The **Student Accounts** workspace is visible only to the `platform_admin` role and calls the deployed `admin-invite-student` Edge Function. It sends a Supabase email invitation; it does not create or reveal a password in the browser.

The login bootstrap now reads the `public.astra_user_profiles` table, and the shared-state adapter targets `public.astra_app_state`. Events, notification inboxes, profile directory lookups and audit reads are mapped to the deployed campus tables. Some older operational pages remain prototype/legacy workflows and are not all migrated to the new campus schema yet.
