# ASTRA POINT v0.23.0 — local terminal update

## Changes made in source
- Added a Teams workspace to the existing admin application.
- Seeded empty team shells for sports, technical competition and cultural representation; no students or results are fabricated.
- Platform admins can create/delete teams, update season and coach, and add/remove roster members. Other permitted roles are view-only.
- Added a Website CMS workspace for the homepage headline, subtitle, welcome banner and about copy.
- Connected those homepage fields to the public portal through local browser storage and a same-browser update event.
- Retained the Hall of Fame submission/review flow and the supplied club directory.
- Updated package version to 0.23.0.
- No Supabase SQL was applied and no remote data was changed.

## Current limits
- Team, Hall of Fame and Website CMS records are browser-local, not multi-device/shared Supabase records.
- The live Supabase project previously reported inactive. A safe shared-data integration requires restoring access and auditing existing tables/RLS before proposing a migration.
- Production build could not be run because package installation timed out and the npm package cache does not contain required dependencies. A global TypeScript pass found no syntax errors in the changed files, but reports missing installed packages/types; therefore a production build is not claimed as passing.

## Run locally
1. Extract the ZIP.
2. Run `npm install` in the project folder (internet/package registry access required).
3. Copy `.env.example` to `.env` and fill in your existing Supabase URL and publishable key if available. Do not put service-role secrets in browser variables.
4. Run `npm run dev`.
5. Sign in with a platform-admin account and open **Teams** or **Website CMS** in the sidebar.
