# Connected Supabase backend status — 1 Nov 2026

This frontend package targets the existing ASTRA POINT project `noobyuyuwcjghyxszauq` in `ap-south-1`.

## Deployed to the connected project

- Campus schema migration `astra_point_2_student_campus_core`
- Profile backfill and policy hardening `astra_point_profile_backfill_and_policy_hardening`
- Storage buckets and access policies `astra_point_storage_buckets_and_access`
- RLS refinements and realtime publication `astra_point_rls_refinements_and_realtime`
- Edge Function `admin-invite-student` (ACTIVE, JWT verification enabled)

## Verified state at packaging

- 29 public application tables; RLS enabled on all 29
- 4 storage buckets: `student-avatars`, `campus-public-media`, `student-private-files`, `project-media`
- 16 public tables added to Supabase Realtime
- Existing two Auth users and two profile records preserved
- No student invitation was sent and no new student Auth user was created by this packaging task
- Existing `astra_app_state` rows were not deleted

## Important deployment note

The connected project has already received these changes. The historical SQL for the new campus migrations is held in the Supabase migration history, not reconstructed as fake local migration files in this ZIP. Do not blindly replay the legacy migrations in `supabase/migrations` against the already-upgraded production project. For a new Supabase project, generate and review a fresh schema baseline/migration before deploying.

## Security note

Only the browser-safe publishable key is supplied in `.env.example`. The student-invite Edge Function uses the Supabase server-side secret/service-role environment variable inside Supabase and verifies the caller's JWT plus active `platform_admin` profile. Never copy a secret key into `VITE_*`, `.env.example`, frontend code, or Git.

The Supabase security advisor's remaining warning at packaging time was that leaked-password protection was disabled. Enable it under Authentication → Settings → Password Security.
